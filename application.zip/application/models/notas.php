<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Notas extends CI_Model {

// Id	
	private $id = null;

// Save data	
	private $data = array();

// Table usage	
	private $table = 't_notas';
	
		
    public function __construct(){  parent::__construct(); }
	

/*
====================================
	Funciones CRUD
==================================== */
	public function crear( $values = array() ){
		
		// Validar información
		if( empty( $values ) ) return false;
		
		// Configurar información a guardar
		foreach( $values as $key => $value )									
				$this->data[$key] = $value ; 		
		
		
		// Crear registro	
	    if( $this->db->insert( $this->table, $this->data )  )
        	return true;
        else
        	return false;
        
		
	}

	public function incidencia( $incidencia = null  ){
		
		if( empty( $incidencia ) or !is_numeric( $incidencia ) ) return false;
		
		unset( $this->data ); $this->data = array();
				
		// Consulta
		$this->db->select( 'notas, fecha, firmausuario' )->from( $this->table )->where( array( 'id_incidencia' => $incidencia ) )->order_by( 'id_notas', 'desc' );
		
		$query = $this->db->get(  );
		
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			foreach ( $query->result() as $row ){
				
				
				$this->data[] = array( 
					
					'notas' => $row->notas,
					'fecha' => $row->fecha,
					'usuario'=> $row->firmausuario
										
				);
		  
			}
			
			return $this->data;	
				
		}else
			return false;
		
	}
		
}
?>