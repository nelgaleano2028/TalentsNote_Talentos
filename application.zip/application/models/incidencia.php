<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Incidencia extends CI_Model {

// Id	
	private $id = null;

// Save data	
	private $data = array();

// Table usage	
	private $table = 't_incidencia';
	
		
    public function __construct(){  parent::__construct(); }
	

/*
====================================
	Funciones CRUD
==================================== */	
	public function crear( $values = array() ){
		
		
		$cliente=$this->login[0]['id_contacto'];
		
		// Validar información
		if( empty( $values ) ) return false;
		
		// Configurar información a guardar
		foreach( $values as $key => $value )									
				$this->data[$key] = $value ; 		
		
		unset($this->data['categorias'] );
		
		
		$this->data['id_estado'] = 1;
		$this->data['fecha'] = date( 'Y-m-d H-i-s' );
		
		// Load model
		$this->load->model( 'ingenieros' );
		
		$ingeniero = $this->ingenieros->asignar_ingeniero( $values['id_area'] );
		
		$this->data['id_ingeniero'] = $ingeniero[0]['id_ingeniero'];
						
		// Crear registro	
	    if( $this->db->insert( $this->table, $this->data )  ){
			
        	
			if($this->correo_nuevo($this->db->insert_id() ) == true)
			return true;
			else
			return false;
			
		}else
        	return false;
		
	}
	
	public function correo_nuevo( $incidente= null){
	
		// Validacion id
		if( empty( $incidente ) or !is_numeric( $incidente ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		// Consulta
		$this->db->select("t_incidencia.id_incidencia,t_incidencia.asunto,t_incidencia.detalle,
		t_incidencia.fecha,t_incidencia.imagen,t_estado.nombre_estado,t_cliente.nombre_cliente,
        t_condicion.descripcion,t_causa.nombre_causa,t_ingeniero.correo,t_ingeniero.nombre,
		t_contacto.correo as correo_contacto");
		$this->db->from($this->table);
		$this->db->join('t_estado', 't_estado.id_estado = t_incidencia.id_estado');
		$this->db->join('t_cliente', 't_cliente.id_cliente = t_incidencia.id_cliente');
		$this->db->join('t_condicion', 't_condicion.id_condicion = t_incidencia.id_condicion');
		$this->db->join('t_causa', 't_causa.id_causa = t_incidencia.causa');
		$this->db->join('t_ingeniero', 't_ingeniero.id_ingeniero = t_incidencia.id_ingeniero');
		$this->db->join('t_contacto', 't_contacto.id_contacto = t_incidencia.id_contacto');
		
		$this->db->where('id_incidencia', $incidente); 
		  
		$query=$this->db->get();
		
		
		if($query->num_rows != 0){
			
			foreach($query->result() as $row){
				
				 $this->load->library('My_PHPMailer');
						 $mail = new PHPMailer();
						 $mail->Host = "localhost";
						 $mail->From = "administracion@afqsas.com"; 
						 $mail->FromName = "Administrador AFQsas";
						 $mail->Subject = $row->asunto;
						 $mail->AddAddress($row->correo,'ingeniero');
						 $mail->AddAddress($row->correo_contacto,'cliente');
						 $mail->AddAddress("administracion@afqsas.com","Administracion AFQ sas");
						 $body = '<table width="100%" cellpadding="0" cellspacing="0" border="0" id="background-table">
									<tbody><tr>
										<td align="center" bgcolor="#c7c7c7">
											<table class="w640" style="margin:0 10px;" width="640" cellpadding="0" cellspacing="0" border="0">
												<tbody><tr><td class="w640" width="640" height="20"></td></tr>
												
												<tr>
													<td class="w640" width="640"><table id="top-bar" class="w640" width="640" cellpadding="0" cellspacing="0" border="0" bgcolor="#000000">
									<tbody><tr>
										<td class="w15" width="15"></td>
										<td class="w325" width="350" valign="middle" align="left">&nbsp;</td>
										<td class="w30" width="30"></td>
										<td class="w255" width="255" valign="middle" align="right"><table cellpadding="0" cellspacing="0" border="0">
										  <tbody><tr>	
									</tr>
								</tbody></table></td>
										<td class="w15" width="15"></td>
									</tr>
								</tbody></table>
														
													</td>
												</tr>
												<tr>
												<td id="header" class="w640" width="640" align="center" bgcolor="#000000">
									
									<table class="w640" width="640" cellpadding="0" cellspacing="0" border="0">
										<tbody><tr><td class="w30" width="30"></td><td class="w580" width="580" height="30"><h1 style="color: #47c8db !important; font: bold 32px Helvetica, Arial, sans-serif; margin: 0; padding: 0; line-height: 40px;"><singleline label="Title">Administrador AFQsas</singleline></h1></td><td class="w30" width="30"></td></tr>
										<tr>
											<td class="w30" width="30"></td>
											<td class="w580" width="580">
												<div align="center" id="headline">
													<p>
														<strong><singleline style="color: #47c8db !important; font:  32px Helvetica, Arial, sans-serif; margin: 0; padding: 0; line-height: 40px;"label="Title">Detalle del Incidente</singleline></strong>
													</p>
												</div>
											</td>
											<td class="w30" width="30"></td>
										</tr>
									</tbody></table>
									
									
								</td>
												</tr>
												
												<tr><td class="w640" width="640" height="30" bgcolor="#ffffff"></td></tr>
												<tr id="simple-content-row"><td class="w640" width="640" bgcolor="#ffffff">
									<table class="w640" width="640" cellpadding="0" cellspacing="0" border="0">
										<tbody><tr>
											<td class="w30" width="30"></td>
											<td class="w580" width="580">
											  <table cellpadding="0" cellspacing="0" border="0" width="600">
															<tr>
															   <td><strong>Codigo:</strong> </td>
															   <td>'.$row->id_incidencia.'</td>
															</tr>
															<tr>
															   <td>&nbsp;</td>
															   
															</tr>
															 <tr>
															   <td><strong>Estado:</strong> </td>
															   <td>'.$row->nombre_estado.'</td>
															</tr>
															<tr>
															   <td>&nbsp;</td>
															   
															</tr>
								
															 <tr>
															   <td><strong>Prioridad:</strong> </td>
															   <td>'.$row->descripcion.'</td>
															</tr>
															<tr>
															   <td>&nbsp;</td>
															   
															</tr>
								
															 <tr>
															   <td><strong>Causa:</strong></td>
															   <td>'.$row->nombre_causa.'</td>
															</tr>
															<tr>
															   <td>&nbsp;</td>
															   
															</tr>
								
															<tr>
															   <td><strong>Asunto:</strong> </td>
															   <td>'.$row->asunto.'</td>
															</tr>
															<tr>
															   <td>&nbsp;</td>
															   
															</tr>
								
															<tr>
															   <td> <strong>Detalle: </strong></td>
															   <td>'.$row->detalle.'</td>
															</tr>
															<tr>
															   <td>&nbsp;</td>
															   
															</tr>
								
															<tr>
															   <td><strong>Empresa:</strong> </td>
															   <td>'.$row->nombre_cliente.'</td>
															</tr>
															<tr>
															   <td>&nbsp;</td>
															   
															</tr>
								
															 <tr>
															   <td><strong>Fecha Inicial:</strong> </td>
															   <td>'.$row->fecha.'</td>
															</tr>
															
															<tr>
															   <td>&nbsp;</td>
															   
															</tr>
															
															<tr>
															   <td><strong>Ingeniero:</strong> </td>
															   <td>'.$row->nombre.'</td>
															</tr>
															
															</table> 
																
											</td>
											<td class="w30" width="30"></td>
										</tr>
									</tbody></table>
								</td></tr>
												<tr><td class="w640" width="640" height="15" bgcolor="#ffffff"></td></tr>
											</tbody></table>
										</td>
									</tr>
								</tbody></table>';
						 $mail->IsHTML(true); // El correo se envía como HTML
						 $mail->Body = $body;
						 $mail->AltBody = "Talents notes";
						 $mail->AddAttachment("./incidentes/".$row->imagen, $row->imagen );
						 $mail->send();	 		
									
			}
			
			return true;
				
		}else{
			return false;	
		}	
	
	
	}
	
	
	public function editar( $id = null, $values = array() ){
		
		// Validar id e información
		if( empty( $id ) or !is_numeric( $id ) or empty( $values ) ) return false;
			
		
		// Editar registros					
	    if( $this->db->update( $this->table, $values, array( 'id_incidencia' => $id ) ) )
			return true;
		else
        	return false;
        
		
	}
	
	public function eliminar( $id = null ){
		
		// Validar id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		// Eliminar registro					
	    if( $this->db->delete( $this->table, array( 'id_incidencia' => $id ) ) )
        	return true;
        else
        	return false;
        
		
	}
	
/*
====================================
	Funciones Para obtener datos
==================================== */	
	public function all(){
		
		unset( $this->data ); $this->data = array();
				
		// Consulta
		$this->db->select( '*' )->from( $this->table )->order_by( 'id_incidencia', 'desc' );
		$query = $this->db->get();//$this->db->get( $this->table );
		
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			// load model
			$this->load->model( array( 'areas', 'subcategorias', 'categorias', 'ingenieros', 'cliente' ) );
			
			foreach ( $query->result() as $row ){
				
				$area = $this->areas->id( $row->id_area );
				
				$subcategoria = $this->subcategorias->id( $row->id_subcategoria );
			
				$categoria = $this->categorias->id( $subcategoria[0]['relacion'] );
				
				$ingeniero = $this->ingenieros->incidencia( $row->id_ingeniero );
				
				$cliente = $this->cliente->id( $row->id_cliente );
							
				$this->data[] = array( 
					
					'id_incidencia' => $row->id_incidencia,
					'id_categoria' => $categoria[0]['id'],
					'id_subcategoria' => $row->id_subcategoria,
					'id_condicion' => $row->id_condicion,
					'id_estado' => $row->id_estado,
					'id_area' => $row->id_area,
					'area' => $area[0]['nombre_area'],
					'ingeniero' => $ingeniero[0]['nombre'],
					'asunto' => $row->asunto,
					'fecha' => $row->fecha,
					'fecha_final' => $row->fecha_final,
					'detalle' => $row->detalle,
					'cliente' => $cliente[0]['nombre_cliente']
										
				);
		  
			}
			
			return $this->data;	
				
		}else
			return false;
		
	}
	
	public function cliente($id = null){
		// Validacion id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		$this->db->select('t_incidencia.id_incidencia,t_incidencia.asunto,t_incidencia.fecha,
		t_incidencia.id_cliente,t_incidencia.id_condicion,t_estado.nombre_estado,t_condicion.descripcion,
		t_ingeniero.nombre');
		$this->db->from($this->table);
		$this->db->join('t_estado', 't_estado.id_estado = t_incidencia.id_estado');
		$this->db->join('t_condicion', 't_condicion.id_condicion = t_incidencia.id_condicion');
		$this->db->join('t_ingeniero', 't_ingeniero.id_ingeniero = t_incidencia.id_ingeniero');
		$this->db->where('id_cliente', $id); 
		$query=$this->db->get();
		if($query->num_rows != 0){
			
			foreach($query->result() as $row){
				
				$this->load->model(  'tiempoprioridads'  );
				
				 $tiempo = $this->tiempoprioridads->cliente(  $row->id_cliente, $row->id_condicion );
				
				$this->data[]= array(
					'id_incidencia' => $row->id_incidencia,
					'estado'=>$row->nombre_estado,
					'fecha' => $row->fecha,
					'asunto' => $row->asunto,
					'prioridad'=>$row->descripcion,
					'ingeniero'=> $row->nombre,
					'id_condicion'=>$row->id_condicion,
					'tiempo'=>$tiempo
				);
			}
			
			return $this->data;
			
			
		}else{
			return false;	
		}	
	
	}
	
	public function cliente_contacto($id = null){
		// Validacion id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		// Consulta
		$query = $this->db->get_where( $this->table, array( 'id_contacto' => $id ) );
		
		if( $query->num_rows != 0 ){
			
			// load model
			$this->load->model( array( 'areas', 'subcategorias', 'categorias', 'ingenieros', 'cliente' ) );
			
			foreach ( $query->result() as $row ){
				
				$area = $this->areas->id( $row->id_area );
				
				$subcategoria = $this->subcategorias->id( $row->id_subcategoria );
			
				$categoria = $this->categorias->id( $subcategoria[0]['relacion'] );
				
				$ingeniero = $this->ingenieros->incidencia( $row->id_ingeniero );
				
				$cliente = $this->cliente->id( $row->id_cliente );
							
				$this->data[] = array( 
					
					'id_incidencia' => $row->id_incidencia,
					'id_categoria' => $categoria[0]['id'],
					'id_subcategoria' => $row->id_subcategoria,
					'id_condicion' => $row->id_condicion,
					'id_estado' => $row->id_estado,
					'id_area' => $row->id_area,
					'area' => $area[0]['nombre_area'],
					'ingeniero' => $ingeniero[0]['nombre'],
					'asunto' => $row->asunto,
					'fecha' => $row->fecha,
					'fecha_final' => $row->fecha_final,
					'detalle' => $row->detalle,
					'cliente' => $cliente[0]['nombre_cliente'],
					/*'notas'=>$row->notas,*/
					
										
				);
			}
			
			return $this->data;	
			
		}else
			return false;
		
	}
	
	public function id( $id = null ){
		
		// Validacion id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		// Consulta
		$this->db->select('t_incidencia.id_incidencia,t_incidencia.asunto,t_incidencia.fecha,t_incidencia.detalle,
		t_estado.id_estado,t_estado.nombre_estado,t_cliente.nombre_cliente,t_subcategoria.opcion,t_condicion.id_condicion,
		t_condicion.descripcion,t_causa.id_causa,t_causa.nombre_causa');
		$this->db->from($this->table);
		$this->db->join('t_estado', 't_estado.id_estado = t_incidencia.id_estado');
		$this->db->join('t_cliente', 't_cliente.id_cliente = t_incidencia.id_cliente');
		$this->db->join('t_subcategoria', 't_subcategoria.id = t_incidencia.id_subcategoria');
		$this->db->join('t_condicion', 't_condicion.id_condicion = t_incidencia.id_condicion');
		$this->db->join('t_causa', 't_causa.id_causa = t_incidencia.causa');
		$this->db->where('id_incidencia', $id); 
		$query=$this->db->get();
		
		if($query->num_rows != 0){
			
			foreach($query->result() as $row){
				
				$this->data[]= array(
					'id_incidencia' => $row->id_incidencia,
					'id_estado'=>$row->id_estado,
					'estado'=>$row->nombre_estado,
					'fecha' => $row->fecha,
					'asunto' => $row->asunto,
					'subcategoria' => $row->opcion,
					'id_prioridad'=> $row->id_condicion,
					'prioridad'=>$row->descripcion,
					'id_causa'=>$row->id_causa,
					'causa' => $row->nombre_causa,
					'cliente' => $row->nombre_cliente,
					'detalle' => $row->detalle,
				);
			}
			
			return $this->data;
				
		}else{
			return false;	
		}	
			
	}
	
	public function id_ingeniero( $id = null ){
		
		// Validacion id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		// Consulta
		$this->db->select('t_incidencia.id_ingeniero');
		$this->db->from($this->table);
		$this->db->where('id_incidencia', $id); 
		$query=$this->db->get();
		
		if($query->num_rows != 0){
			
			foreach($query->result() as $row){
				
				$this->data[]= array(
					'id_ingeniero' => $row->id_ingeniero,
					
				);
			}
			
			return $this->data;
				
		}else{
			return false;	
		}	
			
	}
	
	public function incidentes_admin( $id = null ){
		
		// Validacion id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		// Consulta
		$this->db->select('t_incidencia.id_incidencia,t_incidencia.asunto,t_incidencia.fecha,t_incidencia.detalle,
		t_estado.id_estado,t_estado.nombre_estado,t_cliente.nombre_cliente,t_subcategoria.opcion,t_condicion.id_condicion,
		t_condicion.descripcion,t_causa.id_causa,t_causa.nombre_causa,t_ingeniero.id_ingeniero as ingeniero,
		t_ingeniero.nombre,(select Usuario from t_usuario where id_ingeniero = ingeniero) as usuario');
		$this->db->from($this->table);
		$this->db->join('t_estado', 't_estado.id_estado = t_incidencia.id_estado');
		$this->db->join('t_cliente', 't_cliente.id_cliente = t_incidencia.id_cliente');
		$this->db->join('t_subcategoria', 't_subcategoria.id = t_incidencia.id_subcategoria');
		$this->db->join('t_condicion', 't_condicion.id_condicion = t_incidencia.id_condicion');
		$this->db->join('t_causa', 't_causa.id_causa = t_incidencia.causa');
		$this->db->join('t_ingeniero', 't_ingeniero.id_ingeniero = t_incidencia.id_ingeniero');
		$this->db->where('id_incidencia', $id); 
		
		$query=$this->db->get();
		
		if($query->num_rows != 0){
			
			foreach($query->result() as $row){
				
				$this->data[]= array(
					'id_incidencia' => $row->id_incidencia,
					'id_estado'=>$row->id_estado,
					'estado'=>$row->nombre_estado,
					'fecha' => $row->fecha,
					'asunto' => $row->asunto,
					'subcategoria' => $row->opcion,
					'id_prioridad'=> $row->id_condicion,
					'prioridad'=>$row->descripcion,
					'id_causa'=>$row->id_causa,
					'causa' => $row->nombre_causa,
					'cliente' => $row->nombre_cliente,
					'detalle' => $row->detalle,
					'ingeniero'=> $row->ingeniero,
					'nombre_ingeniero'=> $row->nombre,
					'usuario'=> $row->usuario
				);
			}
			
			return $this->data;
				
		}else{
			return false;	
		}	
			
	}
	
	public function correo($id = null){
		
		// Validacion id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		// Consulta
		$this->db->select("t_incidencia.id_incidencia,t_incidencia.asunto,t_incidencia.fecha,t_incidencia.fecha_final,
		t_incidencia.imagen,t_estado.nombre_estado,t_cliente.nombre_cliente,t_condicion.descripcion,
	    t_causa.nombre_causa,t_ingeniero.correo,t_ingeniero.nombre,t_contacto.correo as correo_contacto,
		(select notas from t_notas where id_incidencia = ".$id."  order by id_notas desc limit 1) as notas");
		$this->db->from($this->table);
		$this->db->join('t_estado', 't_estado.id_estado = t_incidencia.id_estado');
		$this->db->join('t_cliente', 't_cliente.id_cliente = t_incidencia.id_cliente');
		$this->db->join('t_condicion', 't_condicion.id_condicion = t_incidencia.id_condicion');
		$this->db->join('t_causa', 't_causa.id_causa = t_incidencia.causa');
		$this->db->join('t_ingeniero', 't_ingeniero.id_ingeniero = t_incidencia.id_ingeniero');
		$this->db->join('t_contacto', 't_contacto.id_contacto = t_incidencia.id_contacto');
		$this->db->where('id_incidencia', $id); 
		  
		$query=$this->db->get();
		
		if($query->num_rows != 0){
			
			foreach($query->result() as $row){
				
				$this->data[]= array(
					'id_incidencia' => $row->id_incidencia,
					'estado'=>$row->nombre_estado,
					'fecha' => $row->fecha,
					'fecha_final'=>$row->fecha_final,
					'asunto' => $row->asunto,
					'prioridad'=>$row->descripcion,
					'causa' => $row->nombre_causa,
					'cliente' => $row->nombre_cliente,
					'correo_ingeniero'=> $row->correo,
					'ingeniero'=> $row->nombre,
					'correo_contacto'=> $row->correo_contacto,
					'imagen'=>$row->imagen,
					'notas'=>$row->notas
				);
			}
			
			return $this->data;
				
		}else{
			return false;	
		}	
			
	}
	
	public function imagen( $id = null ){
		
		// Validacion id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		// Consulta
		$query = $this->db->get_where( $this->table, array( 'id_incidencia' => $id ) );
		
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			
			foreach ( $query->result() as $row ){
			
				
				$this->data[] = array( 
					
					'imagen' => $row->imagen,
					
										
				);
				
		  
			}
			
			return $this->data;	
				
		}else
			return false;
		
	}
	
    public function update_imagen( $id = null ){
		
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); 
		
	    $imagen_update=array(
			'imagen'=>'no_disponible.png'
		);	
	
		// Editar registros					
	    if( $this->db->update( $this->table, $imagen_update, array( 'id_incidencia' => $id ) ) )
        	return true;
        else
        	return false;
		
	}
	
	public function imprimir_id( $id = null ){
		
		// Validacion id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		// Consulta
		$query = $this->db->get_where( $this->table, array( 'id_incidencia' => $id ) );
		
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			// load model
			$this->load->model( array( 'subcategorias', 'categorias', 'cliente', 'ingenieros', 'contactos' ) );
			
			foreach ( $query->result() as $row ){
			
				$subcategoria = $this->subcategorias->id( $row->id_subcategoria );
				
				$cliente = $this->cliente->id( $row->id_cliente );
			
				$categoria = $this->categorias->id( $subcategoria[0]['relacion'] );
				
				$ingeniero = $this->ingenieros->id( $row->id_ingeniero );
				
				$contactos = $this->contactos->cliente( $row->id_cliente );
				
				$contacto= $this->contactos->contacto_incidente( $row->id_contacto );
				
				
				$estado=($row->id_estado == 1)?'abierto':'cerrado';
				
				 switch($row->id_condicion): 
				 
					 case 1:
						$prioridad= 'Alta';
					 break;
					 case 2:
						$prioridad= 'Media';
					 break;
					 case 3:
						$prioridad= 'Baja';
					 break;
				 
				 
				 endswitch;
				 
				 $fecha=substr($row->fecha, 0, -9);
				 $fecha_final=substr($row->fecha_final, 0, -9);
				 
				
				$this->data[] = array( 
					
					'id_incidencia' => $row->id_incidencia,
					'categoria' => $categoria[0]['opcion'],
					'subcategoria' => $subcategoria[0]['opcion'],
					'prioridad' => $prioridad,
					'estado' => $estado,
					'fecha' => $fecha,
					'fecha_final' => $fecha_final,
					'asunto' => $row->asunto,
					'cliente' => $cliente[0]['nombre_cliente'],
					'ingeniero' => $ingeniero[0]['nombre'],
					'detalle' => $row->detalle,
					'contacto' => $contacto[0]['nombre']
										
				);
				
			}
			
			return $this->data;	
				
		}else
			return false;
		
	}
	
	public function ingeniero( $id = null ){
		
		// Validacion id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		$this->db->select('t_incidencia.id_incidencia,t_incidencia.asunto,t_incidencia.fecha,t_incidencia.id_ingeniero,
		t_estado.nombre_estado,t_cliente.id_cliente,t_cliente.nombre_cliente,t_condicion.id_condicion,
		t_condicion.descripcion');
		$this->db->from($this->table);
		$this->db->join('t_estado', 't_estado.id_estado = t_incidencia.id_estado');
		$this->db->join('t_cliente', 't_cliente.id_cliente = t_incidencia.id_cliente');
		$this->db->join('t_condicion', 't_condicion.id_condicion = t_incidencia.id_condicion');
		$this->db->where('t_incidencia.id_ingeniero', $id); 
		$this->db->where('t_incidencia.id_estado <>',  '2');
		$query=$this->db->get();
		if($query->num_rows != 0){
			
			foreach($query->result() as $row){
				
				$this->load->model(  'tiempoprioridads'  );
				
				 $tiempo = $this->tiempoprioridads->cliente(  $row->id_cliente, $row->id_condicion );
				
				$this->data[]= array(
				
					'id_incidencia' => $row->id_incidencia,
					'id_condicion' => $row->id_condicion,
					'id_ingeniero' => $row->id_ingeniero,
					'estado'=> $row->nombre_estado,
					'cliente' => $row->nombre_cliente,
					'asunto' => $row->asunto,
					'fecha' => $row->fecha,
					'tiempo' => $tiempo
				
				
				);
			}
			
			return $this->data;
			
			
		}else{
			return false;	
		}	
		
		
	}
	
	public function ingenierotodas( $id = null ){
		
		// Validacion id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		$this->db->select( '*' )->from( $this->table )->where( array( 'id_ingeniero' => $id ) )->order_by( 'id_incidencia', 'desc' );
						
		// Consulta
		$query = $this->db->get();
		
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			// Load Model
			$this->load->model( array( 'cliente', 'contactos' ) );	
						
			foreach ( $query->result() as $row ){
				
				$contactos = $this->contactos->id( $row->id_contacto );
				
				$cliente = $this->cliente->id( $row->id_cliente );
				
			    $this->data[] = array( 
					
					'id_incidencia' => $row->id_incidencia,
					'id_condicion' => $row->id_condicion,
					'id_ingeniero' => $row->id_ingeniero,
					'id_estado' => $row->id_estado,
					'id_area' => $row->id_area,
					'cliente' => $cliente[0]['nombre_cliente'],
					'asunto' => $row->asunto,
					'fecha' => $row->fecha,
					'fecha_final' => $row->fecha_final,
					'contacto' => $contactos[0]['nombre']
										
				);
		  
			}
			
			return $this->data;	
				
		}else
			return false;
		
	}
	
	public function clientetodas( $id = null ){
		
		// Validacion id
		if( empty( $id ) or !is_numeric( $id ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		$this->db->select( '*' )->from( $this->table )->where( array( 'id_ingeniero' => $id ) )->order_by( 'id_incidencia', 'desc' );
						
		// Consulta
		$query = $this->db->get();
		
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			// Load Model
			$this->load->model( array( 'cliente', 'contactos' ) );	
						
			foreach ( $query->result() as $row ){
				
				$contactos = $this->contactos->cliente( $row->id_cliente );
				
				$cliente = $this->cliente->id( $row->id_cliente );
				
			    $this->data[] = array( 
					
					'id_incidencia' => $row->id_incidencia,
					'id_condicion' => $row->id_condicion,
					'id_ingeniero' => $row->id_ingeniero,
					'id_estado' => $row->id_estado,
					'id_area' => $row->id_area,
					'cliente' => $cliente[0]['nombre_cliente'],
					'asunto' => $row->asunto,
					'fecha' => $row->fecha,
					'fecha_final' => $row->fecha_final,
					'contacto' => $contactos
										
				);
		  
			}
			
			return $this->data;	
				
		}else
			return false;
		
	}
	
	public function realizadas( $cliente = null, $ingeniero = null, $fecha = null ){
		
		// Validacion id
		if( empty( $cliente ) or empty( $ingeniero ) or empty( $fecha ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		$fecha = explode( '/', $fecha );
		$fecha = $fecha[2].'-'.$fecha[1].'-'.$fecha[0];
		
		// Consulta
		$query = $this->db->query( 
		
			'
				SELECT count(*) as numero 
				FROM '.$this->table.'
				WHERE id_ingeniero=\''.strip_tags( $ingeniero ).'\' 
				AND id_cliente= \''.strip_tags( $cliente ).'\' 
				AND id_estado=2 
				AND DATE(fecha) = \''.strip_tags( $fecha ).'\'
			
			' 
			
		);
				
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			foreach ( $query->result() as $row ){
			
							
				$this->data[] = array( 
					
					'numero' => $row->numero,
															
				);
		  
			}
			
			return $this->data;	
				
		}else{
		
			$this->data[0]['numero'] = 0;
			return $this->data;
		}
		
		
		
	}
	
	public function no_realizadas( $cliente = null, $ingeniero = null, $fecha = null ){
		
		// Validacion id
		if( empty( $cliente ) or empty( $ingeniero ) or empty( $fecha ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		$fecha = explode( '/', $fecha );
		$fecha = $fecha[2].'-'.$fecha[1].'-'.$fecha[0];
		
		// Consulta
		$query = $this->db->query( 
		
			'
				SELECT count(*) as numero 
				FROM '.$this->table.'
				WHERE id_ingeniero=\''.strip_tags( $ingeniero ).'\' 
				AND id_cliente= \''.strip_tags( $cliente ).'\' 
				AND id_estado=1
				AND DATE(fecha) = \''.strip_tags( $fecha ).'\'
			
			' 
			
		);
				
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			foreach ( $query->result() as $row ){
			
							
				$this->data[] = array( 
					
					'numero' => $row->numero,
															
				);
		  
			}
			
			return $this->data;	
				
		}else{
		
			$this->data[0]['numero'] = 0;
			return $this->data;
		}
		
	}
	
	
	public function realizadas_ingeniero_fecha( $ingeniero = null, $fecha1 = null, $fecha2 = null ){
		
		
		// Validacion id
		if( empty( $ingeniero ) or empty( $fecha1 ) or empty ($fecha2) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		$fecha1 = explode( '/', $fecha1 );
		$fecha1 = $fecha1[2].'-'.$fecha1[1].'-'.$fecha1[0];
		$fecha2 = explode( '/', $fecha2 );
		$fecha2 = $fecha2[2].'-'.$fecha2[1].'-'.$fecha2[0];
		
		
		// Consulta
		$query = $this->db->query( 
		
			'
				SELECT count(*) as numero 
				FROM '.$this->table.'
				WHERE id_ingeniero=\''.strip_tags( $ingeniero ).'\' 
				AND id_estado=2 
				AND
				DATE(fecha)
				BETWEEN
				\''.strip_tags( $fecha1 ).'\'
				AND
			    \''.strip_tags( $fecha2 ).'\'

			' 
			
		);
				
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			foreach ( $query->result() as $row ){
			
							
				$this->data[] = array( 
					
					'numero' => $row->numero,
															
				);
		  
			}
			
			return $this->data;	
				
		}else{
		
			$this->data[0]['numero'] = 0;
			return $this->data;
		}
		
		
		
	}
	
	public function no_realizadas_ingeniero_fecha( $ingeniero = null, $fecha1 = null, $fecha2 = null ){
		
		// Validacion id
		if( empty( $ingeniero ) or empty( $fecha1 ) or empty ($fecha2) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		$fecha1 = explode( '/', $fecha1 );
		$fecha1 = $fecha1[2].'-'.$fecha1[1].'-'.$fecha1[0];
		$fecha2 = explode( '/', $fecha2 );
		$fecha2 = $fecha2[2].'-'.$fecha2[1].'-'.$fecha2[0];
		
		// Consulta
		$query = $this->db->query( 
		
			'
				
				SELECT count(*) as numero 
				FROM '.$this->table.'
				WHERE id_ingeniero=\''.strip_tags( $ingeniero ).'\' 
				AND id_estado=1 
				AND
				DATE(fecha)
				BETWEEN
				\''.strip_tags( $fecha1 ).'\'
				AND
			    \''.strip_tags( $fecha2 ).'\'
			
			' 
			
		);
				
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			foreach ( $query->result() as $row ){
			
							
				$this->data[] = array( 
					
					'numero' => $row->numero,
															
				);
		  
			}
			
			return $this->data;	
				
		}else{
		
			$this->data[0]['numero'] = 0;
			return $this->data;
		}
		
	}
	
	public function rango_fecha( $ingeniero = null, $de = null, $a = null ){
		
		// Validacion id
		if( empty( $ingeniero ) or empty( $de ) or empty( $a ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		$de = explode( '/', $de );
		$de = $de[2].'-'.$de[1].'-'.$de[0];
		
		$a = explode( '/', $a );
		$a = $a[2].'-'.$a[1].'-'.$a[0];
		// Consulta
		$query = $this->db->query( 
		
			'
				SELECT * 
				FROM '.$this->table.'
				WHERE id_ingeniero=\''.strip_tags( $ingeniero ).'\' 
				AND DATE(fecha) BETWEEN \''.strip_tags( $de ).'\' AND \''.strip_tags( $a ).'\'
			
			' 
			
		);
				
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			// load model
			$this->load->model( array( 'subcategorias', 'categorias', 'cliente', 'ingenieros', 'contactos' ) );
			
			foreach ( $query->result() as $row ){
			
				$subcategoria = $this->subcategorias->id( $row->id_subcategoria );
				
				$cliente = $this->cliente->id( $row->id_cliente );
			
				$categoria = $this->categorias->id( $subcategoria[0]['relacion'] );
				
				$ingeniero = $this->ingenieros->id( $row->id_ingeniero );
				
				$contactos = $this->contactos->cliente( $row->id_cliente );
				
				$estado=($row->id_estado == 1)?'abierto':'cerrado';
				
				 switch($row->id_condicion): 
				 
					 case 1:
						$prioridad= 'Alta';
					 break;
					 case 2:
						$prioridad= 'Media';
					 break;
					 case 3:
						$prioridad= 'Baja';
					 break;
				 
				 
				 endswitch;
				 
				 $fecha=substr($row->fecha, 0, -9);
				 $fecha_final=substr($row->fecha_final, 0, -9);
				
				$this->data[] = array( 
					
					'id_incidencia' => $row->id_incidencia,
					'categoria' => $categoria[0]['opcion'],
					'subcategoria' => $subcategoria[0]['opcion'],
					'prioridad' => $prioridad,
					'estado' => $estado,
					'fecha' => $fecha,
					'fecha_final' => $fecha_final,
					'asunto' => $row->asunto,
					'cliente' => $cliente[0]['nombre_cliente'],
					'ingeniero' => $ingeniero[0]['nombre'],
					'detalle' => $row->detalle,
					'contacto' => $contactos[0]['nombre']
										
				);
		  
			}
			
			return $this->data;	
				
		}else
			return false;
		
	}	
	
	
	public function rango_fecha_cliente( $contacto = null, $de = null, $a = null ){
		
		// Validacion id
		if( empty( $contacto ) or empty( $de ) or empty( $a ) ) return false;
		
		unset( $this->data ); $this->data = array();
		
		$de = explode( '/', $de );
		$de = $de[2].'-'.$de[1].'-'.$de[0];
		
		$a = explode( '/', $a );
		$a = $a[2].'-'.$a[1].'-'.$a[0];
		// Consulta
		$query = $this->db->query( 
		
			'
				SELECT * 
				FROM '.$this->table.'
				WHERE id_contacto=\''.strip_tags( $contacto ).'\' 
				AND DATE(fecha) BETWEEN \''.strip_tags( $de ).'\' AND \''.strip_tags( $a ).'\'
			
			' 
			
		);
				
		// Obtener datos
		if( $query->num_rows != 0 ){
			
			// load model
			$this->load->model( array( 'subcategorias', 'categorias', 'cliente', 'ingenieros', 'contactos' ) );
			
			foreach ( $query->result() as $row ){
			
				$subcategoria = $this->subcategorias->id( $row->id_subcategoria );
				
				$cliente = $this->cliente->id( $row->id_cliente );
			
				$categoria = $this->categorias->id( $subcategoria[0]['relacion'] );
				
				$ingeniero = $this->ingenieros->id( $row->id_ingeniero );
				
				$contactos = $this->contactos->cliente( $row->id_cliente );
				
				$estado=($row->id_estado == 1)?'abierto':'cerrado';
				
				 switch($row->id_condicion): 
				 
					 case 1:
						$prioridad= 'Alta';
					 break;
					 case 2:
						$prioridad= 'Media';
					 break;
					 case 3:
						$prioridad= 'Baja';
					 break;
				 
				 
				 endswitch;
				 
				 $fecha=substr($row->fecha, 0, -9);
				 $fecha_final=substr($row->fecha_final, 0, -9);
				
				$this->data[] = array( 
					
					'id_incidencia' => $row->id_incidencia,
					'categoria' => $categoria[0]['opcion'],
					'subcategoria' => $subcategoria[0]['opcion'],
					'prioridad' => $prioridad,
					'estado' => $estado,
					'fecha' => $fecha,
					'fecha_final' => $fecha_final,
					'asunto' => $row->asunto,
					'cliente' => $cliente[0]['nombre_cliente'],
					'ingeniero' => $ingeniero[0]['nombre'],
					'detalle' => $row->detalle,
					'contacto' => $contactos[0]['nombre']
										
				);
		  
			}
			
			
			return $this->data;	
				
		}else
			return false;
		
	}	
			
}
?>