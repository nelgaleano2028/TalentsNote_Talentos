<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Exp{
	
	private $header = '
	
		<table cellpadding="0" cellspacing="0" border="1" align="center" >
		  
			  <tr bgcolor="#909393">
				  <td><font color="#ffffff"><strong>Codigo</strong></font></td>
				  <td><font color="#ffffff"><strong>Categoria</strong></font></td>
				  <td><font color="#ffffff"><strong>Subcategoria</strong></font></td>
				  <td><font color="#ffffff"><strong>Prioridad</strong></font></td>
				  <td><font color="#ffffff"><strong>Estado</strong></font></td>
				  <td><font color="#ffffff">Fecha</strong></font></td>
				  <td><font color="#ffffff">Fecha Final</strong></font></td>
				  <td><font color="#ffffff"><strong>Asunto</strong></font></td>
				  <td><font color="#ffffff"><strong>Cliente</strong></font></td>
				  <td><font color="#ffffff"><strong>Ingeniero</strong></font></td> 
				  <td><font color="#ffffff"><strong>Detalle</strong></font></td>
				  <td><font color="#ffffff"><strong>Contacto</strong></font></td>
				  		  
			  </tr>
		 	
	';	
	
	private $body = '';
	
	
	private $footer = '
			
			
		
			  <tr>
				  <td>Codigo</td>
				  <td>Categoria</td>
				  <td>Subcategoria</td>
				  <td>Prioridad</td>
				  <td>Estado</td>
				  <td>Fecha</td>
				  <td>Fecha Final</td>
				  <td>Asunto</td>	
				  <td>Cliente</td> 
				  <td>Ingeniero</td>
				  <td>Detalle</td>
				  <td>Contacto</td>
				  
				    
			  </tr>
		 
		 
	
	';
	
	public function onlyExport( $data = array() ){
		
		if( empty( $data ) ){ $this->body = '<tr><td colspan="8">No hay registros</td> </tr>'; return $this->header.$this->body.$this->footer; }
		
		$this->body .='	
			
			<tr >
			  <td>'.$data[0]['id_incidencia'] .'</td>
			  <td>'.$data[0]['categoria'] .'</td>
			  <td>'.$data[0]['subcategoria'] .'</td>
			  <td>'.$data[0]['prioridad'] .'</td>
			  <td>'.$data[0]['estado'] .'</td>
			  <td class="center">'. $data[0]['fecha'] .'</td>
			  <td class="center">'. $data[0]['fecha_final'] .'</td>
			  <td class="center">'. $data[0]['asunto'] .'</td>
			  <td class="center">'. $data[0]['cliente'] .'</td>
			  <td class="center">'. $data[0]['ingeniero'] .'</td>
			  <td class="center">'. $data[0]['detalle'] .'</td>
			  <td class="center">'. $data[0]['contacto'] .'</td>
			  
			  
				
		  </tr>';
		 
		return $this->header.$this->body.$this->footer;
		 		
	}
	
	public function fullExport( $data = array() ){
		
		if( empty( $data ) ){ $this->body = '<tr><td colspan="8">No hay registros</td> </tr>'; return $this->header.$this->body.$this->footer; }
		
		foreach( $data as $value ){
		
				$this->body .='	
					
					<tr >
					  <td>'.$value['id_incidencia'] .'</td>
					  <td>'.$value['categoria'] .'</td>
					  <td>'.$value['subcategoria'] .'</td>
					  <td>'.$value['prioridad'] .'</td>
					  <td>'.$value['estado'] .'</td>
					  <td class="center">'. $value['fecha'] .'</td>
					  <td class="center">'. $value['fecha_final'] .'</td>
					  <td class="center">'. $value['asunto'] .'</td>
					  <td class="center">'. $value['cliente'] .'</td>
					  <td class="center">'. $value['ingeniero'] .'</td>
					  <td class="center">'. $value['detalle'] .'</td>
					  <td class="center">'. $value['contacto'] .'</td>
				  </tr>';
		
		}
				 
		return $this->header.$this->body.$this->footer;
		 		
	}


}
?>