<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

	<!--menu-->
      <div id="menu">
         <ul id="fade" class="top-level">
            <li class="quitar"><a href="<?php echo base_url()?>admin/" id="inicio-hover" >
            	
                 <?php if( $section == 'inicio' ): ?>
                	
                	<img src="<?php echo base_url() ?>images/home_hover.png" title="">
             	
                <?php else: ?>
                	
                    <img src="<?php echo base_url() ?>images/home.png" title="">
                    
                <?php endif; ?>
            
            </a>
            </li>
            
           
            
            <li class="quitar"><a href="<?php echo base_url()?>ingeniero/ver_incidentes_clientes/<?php echo $login[0]['id_ingeniero'] ?>" id="talentos-hover" >
            
				<?php if( $section == 'lista' ): ?>
                    
                        <img src="<?php echo base_url() ?>images/ver_hover.png" title=""></a>
                    
                <?php else: ?>
                        
                        <img src="<?php echo base_url() ?>images/ver.png" title=""></a>
                    
                <?php endif; ?>
            
            </a>
                <ul class="sub-level2">
                        
                        <li class="quitar"><a href="<?php echo base_url()?>ingeniero/ver_incidentes_clientes/<?php echo $login[0]['id_ingeniero'] ?>" >Ver incidentes</a></li> 
                                
                                    
                        <li class="quitar"><a href="<?php echo base_url()?>ingeniero/libreta/" >Libreta direcciones</a></li>
                                     
                 </ul>
            </li>
            <li class="quitar"><a href="<?php echo base_url()?>ingeniero/perfil_ingeniero/<?php echo $login[0]['id_ingeniero'] ?>" id="lista-hover" >
            	
                <?php if( $section == 'nuevo' ): ?>
                    
                        <img src="<?php echo base_url() ?>images/perfil_hover.png" title=""></a>
                    
                <?php else: ?>
                        
                        <img src="<?php echo base_url() ?>images/perfil.png" title=""></a>
                    
                <?php endif; ?>
            
            </a>
            </li>
            <li class="quitar"><a href="<?php echo base_url()?>ingeniero/reportes" id="nuevo-hover" >
            
            	<?php if( $section == 'ver' ): ?>
                    
                        <img src="<?php echo base_url() ?>images/reporte_hover.png" title=""></a>
                    
                <?php else: ?>
                        
                        <img src="<?php echo base_url() ?>images/reporte.png" title=""></a>
                    
                <?php endif; ?>
            
            </a>
            </li>
            
            </li>
            <li class="quitar"><a href="<?php echo base_url()?>usuario/logout" ><img src="<?php echo base_url() ?>images/salir.png" title="salir"></a>
            </li>
          </ul>
      </div>
      	<!--fin menu-->   