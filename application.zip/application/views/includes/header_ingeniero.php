<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php echo doctype('html5'); ?>

<head>
	<?php echo meta('Content-type', 'text/html; charset=utf-8', 'equiv'); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
	<title><?php echo $title ?></title>
    <!--[if lt IE 9]>
	<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
	<![endif]-->
    
    <link href='http://fonts.googleapis.com/css?family=Quattrocento' rel='stylesheet' type='text/css'>
    
    <link rel="stylesheet" href="<?php echo base_url() ?>style/style.css?<?php echo date('Y-m-d H:i:s'); ?>" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo base_url() ?>style/responsive.css?<?php echo date('Y-m-d H:i:s'); ?>" type="text/css" media="screen" />
    <link href='<?php echo base_url()?>style/mensajes.css?<?php echo date('Y-m-d H:i:s'); ?>' rel='stylesheet' type='text/css'>
    <link href='<?php echo base_url()?>style/menu.css?<?php echo date('Y-m-d H:i:s'); ?>' rel='stylesheet' type='text/css'>
           
	<!-- Print dinamical files css -->
	<?php 
	if( !empty( $css ) ):
		
		foreach( $css as $key => $value ):
				
			echo $value ;
		
		endforeach;
				
	endif;
	?>
	<!-- EndPrint dinamical files css -->
        
    
	
</head>

<body> 

<div id="header">
    	<div class="head-0">
        	<div class="wrap">
            	<div class="logo">
                	<img src="<?php echo base_url()?>images/logo.png">
                </div>
            </div>
        </div>        
</div><div class="clear"></div>
<!--fin header-->
<div id="menu_arriba">

		 <div class="users-online">
            <a href="#" class="bt btmiddle"><img src="<?php echo base_url()?>usuarios/<?php echo $usuario[0]['img'] ?>" width="40" height="40"><span>&#9660;</span></a>
        </div>
		<div class="user-name">
            <span id="name">Usuario: <?php echo $usuario[0]['Usuario']?></span>
            
        </div>
        
       
        <div class="clear"></div>
        <div id="tool-tip">
        	<div id="triangle"></div>
            <div id="tooltip_menu">
            	<a href="<?php echo base_url()?>ingeniero/perfil_ingeniero/<?php echo $login[0]['id_ingeniero'] ?>" class="menu_top">
                <img src="<?php echo base_url()?>images/1.png"/>
                	Perfil
                </a>
                <a href="<?php echo base_url()?>usuario/logout/" class="menu_bottom">
                    <img src="<?php echo base_url()?>images/4.png"/>
                    salir
                </a>
                
            </div>
            
        </div>
</div>
    <!--contenedor-->
    <div id="content">
    	
        <?php 	
			if( $login[0]['id_perfil'] == 2 )
				$this->load->view( 'includes/menu_ingeniero' );
			
			
			
		?>