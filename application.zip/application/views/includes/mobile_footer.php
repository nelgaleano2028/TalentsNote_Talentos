	
    <!-- Grab Google CDN's jQuery, with a protocol relative URL; fall back to local if offline -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.js"></script>


  <!-- scripts concatenated and minified via build script -->
  <script src="<?php echo base_url() ?>plugins/plugins.js"></script>
  <script src="<?php echo base_url() ?>scripts/scripts.js"></script>
  
 
  <!-- end scripts -->
      
  <!-- Print dinamical files js -->
	<?php 
	if( !empty( $scripts ) ):
		
		foreach( $scripts as $key => $value ):
			
			echo $value;
		
		endforeach;
				
	endif;
	?>
    
</body>
</html>