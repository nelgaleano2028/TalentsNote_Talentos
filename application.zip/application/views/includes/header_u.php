<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php echo doctype('html5'); ?>

<head>
	<?php echo meta('Content-type', 'text/html; charset=utf-8', 'equiv'); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
	<title><?php echo $title ?></title>
    <!--[if lt IE 9]>
	<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
	<![endif]-->
    
    <link href='http://fonts.googleapis.com/css?family=Quattrocento' rel='stylesheet' type='text/css'>
    <link href='<?php echo base_url()?>style/mensajes.css?<?php echo date('Y-m-d H:i:s'); ?>' rel='stylesheet' type='text/css'>
   
    
           
	<!-- Print dinamical files css -->
	<?php 
	if( !empty( $css ) ):
		
		foreach( $css as $key => $value ):
				
			echo $value ;
		
		endforeach;
				
	endif;
	?>
	<!-- EndPrint dinamical files css -->
        
    
	
</head>

<body> 