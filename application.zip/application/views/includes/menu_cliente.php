<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<!--menu-->
      <div id="menu">
         <ul id="fade" class="top-level">
            <li class="quitar"><a href="<?php echo base_url()?>admin/" >
            	
                 <?php if( $section == 'inicio' ): ?>
                	
                	<img src="<?php echo base_url() ?>images/home_hover.png" title="home">
             	
                <?php else: ?>
                	
                    <img src="<?php echo base_url() ?>images/home.png" title="home">
                    
                <?php endif; ?>
                
                </a>
            </li>
           
            <li class="quitar"><a href="<?php echo base_url()?>clientes/ver_incidente/" >
            	
                <?php if( $section == 'lista' ): ?>
                	
                	<img src="<?php echo base_url() ?>images/ver_hover.png" title="ver">
             	
                <?php else: ?>
                	
                    <img src="<?php echo base_url() ?>images/ver.png" title="ver">
                    
                <?php endif; ?>
            
                </a>
            	<ul class="sub-level2">
                	
                    <li class="quitar"><a href="<?php echo base_url()?>clientes/ver_incidente/" >Ver incidentes</a></li> 
                            
                                
                                <li class="quitar"><a href="<?php echo base_url()?>clientes/nuevo_incidente/" >Crear incidentes</a></li>
                            
                    
                </ul>
             
            	
            </li>
            <li class="quitar"><a href="<?php echo base_url()?>clientes/perfil_cliente/<?php echo $login[0]['id_usuario'] ?>" >
            
            	<?php if( $section == 'nuevo' ): ?>
                	
                	<img src="<?php echo base_url() ?>images/perfil_hover.png" title="perfil">
             	
                <?php else: ?>
                	
                    <img src="<?php echo base_url() ?>images/perfil.png" title="perfil">
                    
                <?php endif; ?>
            
            </a>
            </li>
            <li class="quitar"><a href="<?php echo base_url()?>clientes/reportes/" >
            
          		<?php if( $section == 'ver' ): ?>
                	
                	<img src="<?php echo base_url() ?>images/reporte_hover.png" title="reportes">
             	
                <?php else: ?>
                	
                    <img src="<?php echo base_url() ?>images/reporte.png" title="reportes">
                    
                <?php endif; ?>
           
            </a>
            </li>
            <li class="quitar"><a href="<?php echo base_url()?>usuario/logout/" ><img src="<?php echo base_url() ?>images/salir.png" title="salir"></a>
            </li>
          </ul>
      </div>
      	<!--fin menu-->   