<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<!--menu-->
      <div id="menu">
         <ul  id="fade" class="top-level">
            
            <li class="quitar"><a href="<?php echo base_url()?>admin/" >
            	
                <?php if( $section == 'inicio' ): ?>
                	
                	<img src="<?php echo base_url() ?>images/home_hover.png" title="home">
             	
                <?php else: ?>
                	
                    <img src="<?php echo base_url() ?>images/home.png" title="home">
                    
                <?php endif; ?>
             
            </a>
 
            	<ul class="sub-level1">
                    <li class="quitar"><div ><a href="<?php echo base_url()?>clientes/crear/" >Crear Clientes</a></div>
                    	<ul class="sub-level1-1">
                        	<li class="quitar"><a href="<?php echo base_url()?>clientes/" >Ver Clientes</a></li>
                            
                        </ul><div class="clear"></div>
                    </li>  
                    
                     <li class="quitar"><div ><a href="<?php echo base_url()?>contacto/crear/" >Crear Contacto</a></div>
                    	<ul class="sub-level1-1">
                        	<li class="quitar"><a href="<?php echo base_url()?>contacto/" >Ver Contacto</a></li>
                            
                        </ul>
                    </li>  
   
            	</ul>
            </li>
            
            <li class="quitar"><a href="<?php echo base_url()?>area/" >
            
            	<?php if( $section == 'lista' ): ?>
            	
                	<img src="<?php echo base_url() ?>images/ingeniero_hover.png" title=""></a>
                
                <?php else: ?>
                	
                    <img src="<?php echo base_url() ?>images/ingeniero.png" title=""></a>
                
                <?php endif; ?>
                
            	<ul class="sub-level2">
                	
                	<li class="quitar"><a href="<?php echo base_url()?>area/crear/" >Crear Áreas </a>
                    	<ul class="sub-level2-1">
                        	<li class="quitar"><a href="<?php echo base_url()?>area/" >Ver Área</a></li>
                              
                        </ul><div class="clear"></div>
                    </li>  
                    
                    
                    <li class="quitar"><a href="<?php echo base_url()?>cesantias/crear/" >Crear Cesantias</a>
                    	<ul class="sub-level2-1">
                        	<li class="quitar"><a href="<?php echo base_url()?>cesantias/" >Ver Cesantias</a></li>
                            
                        </ul>
                    </li>  
                    
                     <li class="quitar"><a href="<?php echo base_url()?>eps/crear/" >Crear Eps</a>
                    	<ul class="sub-level2-1">
                        	<li class="quitar"><a href="<?php echo base_url()?>eps/" >Ver Eps</a></li>
                            
                        </ul><div class="clear"></div>
                    </li>  
                           
                     <li class="quitar"><a href="<?php echo base_url()?>ingeniero/crear" >Crear Ingeniero</a>
                    	<ul class="sub-level2-1">
                        	<li class="quitar"><a href="<?php echo base_url()?>ingeniero/" >Ver Ingeniero</a></li>
                            
                        </ul>
                    </li>         
                                      
                    
                    <li class="quitar"><a href="<?php echo base_url()?>pensiones/Crear/" >Crear Pensiones</a>
                    	<ul class="sub-level2-1">
                        	<li class="quitar"><a href="<?php echo base_url()?>pensiones/" >Ver Pensiones</a></li>
                            
                        </ul>
                    </li>
                    <li class="quitar"><a href="<?php echo base_url()?>cesantias/crear/" >Crear Cesantias</a>
                    	<ul class="sub-level2-1">
                        	<li class="quitar"><a href="<?php echo base_url()?>cesantias/listar" >Listado Cesantias</a></li>
                           
                        </ul>
                    </li>
                    <li class="quitar"><a href="<?php echo base_url()?>cargos/crear/" >Crear Cargos</a>
                    	<ul class="sub-level2-1">
                        	<li class="quitar"><a href="<?php echo base_url()?>cargos/" >Ver Cargos</a></li>
                            
                        </ul>
                    </li>
                    
                    <li class="quitar"><a href="<?php echo base_url()?>causa/crear/" >Crear Causa</a>
                    	<ul class="sub-level2-1">
                        	<li class="quitar"><a href="<?php echo base_url()?>causa/" >Ver Causas</a></li>
                            
                        </ul>
                    </li>
                    
                     <li class="quitar"><a href="<?php echo base_url()?>estado/crear/" >Crear Estados</a>
                    	<ul class="sub-level2-1">
                        	<li class="quitar"><a href="<?php echo base_url()?>estado/" >Ver Estados</a></li>
                            
                        </ul>
                    </li>
                    
                </ul>
            </li>
            <li class="quitar"><a href="<?php echo base_url()?>usuario/" >
            	
                <?php if( $section == 'nuevo' ): ?>
                
               		<img src="<?php echo base_url() ?>images/usuarios_hover.png" title="">
            	
                <?php else: ?>
                	
                    <img src="<?php echo base_url() ?>images/usuarios.png" title="">
                
                <?php endif; ?>
                
                </a>
                
                <ul class="sub-level3">
                	
                  
                        	<li class="quitar"><a href="<?php echo base_url()?>usuario/" >Ver Usuarios</a></li>
                            <li class="quitar"><a href="<?php echo base_url()?>usuario/crear_cliente/" >Crear usuario cliente</a></li>
                            <li class="quitar"><a href="<?php echo base_url()?>usuario/crear_ingeniero/" >Crear usuario ingeniero</a></li>
                  
                </ul>
            </li>
            <li class="quitar"><a href="<?php echo base_url()?>incidencias/" >
            	
                <?php if( $section == 'ver' ): ?>
                
               		<img src="<?php echo base_url() ?>images/incidencias_hover.png" title="ver incidentes">
                
                <?php else: ?>
                	
                    <img src="<?php echo base_url() ?>images/incidencias.png" title="">
                
                <?php endif; ?>
                
                </a>
            	<ul class="sub-level4">
                	<li class="quitar"><a href="<?php echo base_url()?>incidencias/" >Ver Incidencias</a></li>
                    
                    <li class="quitar"><a href="<?php echo base_url()?>categoria/crear/" >Crear Categorías</a>
                        <ul class="sub-level4-1">
                            <li class="quitar"><a href="<?php echo base_url()?>categoria/" >Ver Categorías</a></li>
                           
                        </ul>
                    </li>
                    
                     <li class="quitar"><a href="<?php echo base_url()?>subcategoria/crear/" >Crear Subategoria</a>
                        <ul class="sub-level4-1">
                            <li class="quitar"><a href="<?php echo base_url()?>subcategoria/" >Ver Subategoria</a></li>
                            
                        </ul>
                    </li>
                    
                     <li class="quitar"><a href="<?php echo base_url()?>tiempoprioridad/crear/" >Tiempo prioridad</a>
                        <ul class="sub-level4-1">
                            <li class="quitar"><a href="<?php echo base_url()?>tiempoprioridad/" >Ver Tiempo </a></li>
                            
                        </ul>
                    </li>

                </ul>
            </li>
            <li class="quitar"><a href="<?php echo base_url()?>estadistica/ingenieros/" >
            	<?php if( $section == 'estadistica' ): ?>
                
               		<img src="<?php echo base_url() ?>images/estadistica_hover.png" title="ver incidentes">
                
                <?php else: ?>
                	
                    <img src="<?php echo base_url() ?>images/estadistica.png" title="">
                
                <?php endif; ?>
            
               </a>
               <ul class="sub-level5">
                	
                  
                        	<li class="quitar"><a href="<?php echo base_url()?>estadistica/ingenieros/" >Realizadas</a></li>
                            <li class="quitar"><a href="<?php echo base_url()?>estadistica/ingenieros2/" >No Realizadas</a></li>
                            <li class="quitar"><a href="<?php echo base_url()?>estadistica/ingeniero" >Por Empresa</a></li>
                  
                </ul>
            
            </li>
            <li class="quitar"><a href="<?php echo base_url()?>usuario/logout/" ><img src="<?php echo base_url() ?>images/salir.png" title="salir"></a>
            </li>
          </ul>
      </div>
      	<!--fin menu-->   