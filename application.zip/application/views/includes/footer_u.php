 <!-- JavaScript at the bottom for fast page loading -->

  <!-- Grab Google CDN's jQuery, with a protocol relative URL; fall back to local if offline -->
 <script src="<?php echo base_url() ?>scripts/jquery.js"></script>


  <!-- scripts concatenated and minified via build script -->
  <script src="<?php echo base_url() ?>plugins/plugins.js"></script>
  <script src="<?php echo base_url() ?>scripts/scripts.js"></script>
  
 
  <!-- end scripts -->
      
  <!-- Print dinamical files js -->
	<?php 
	if( !empty( $scripts ) ):
		
		foreach( $scripts as $key => $value ):
			
			echo $value;
		
		endforeach;
				
	endif;
	?>

	
  <!-- Asynchronous Google Analytics snippet. Change UA-XXXXX-X to be your site's ID.
       mathiasbynens.be/notes/async-analytics-snippet -->
  <script>
    var _gaq=[['_setAccount','UA-XXXXX-X'],['_trackPageview']];
    (function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
    g.src=('https:'==location.protocol?'//ssl':'//www')+'.google-analytics.com/ga.js';
    s.parentNode.insertBefore(g,s)}(document,'script'));
  </script>
</body>
</html>