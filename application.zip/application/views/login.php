<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
	
	<div id="form-login">
    	<div id="logo-login">
    		<img src="<?php echo base_url();?>images/logo_login.png"  width="250" height="250"/>
    	</div>
    	<div id="formulario">
            <form action="<?php echo base_url();?>usuario/login" id="formlogin" method="post" accept-charset="utf-8">
            
            <?php $message = $this->session->flashdata( 'message' ); ?>
              
                     <?php if( !empty( $message ) ): ?>
                           
                      <!-- Notification messages -->
                       <div class="nNote">
                           <?php if( $message['type'] == 'failure' ): ?>
                           <div class="nFailure">
                               <p><strong>ERROR: </strong><?php echo $message['text'] ?></p>
                           </div>
                           <?php endif; ?>
                          
                       </div>
                      
                      <?php endif; ?>
                    
                       <?php 
                        $error= validation_errors();
                        
                        if(!empty($error)):
                        ?>
                            <div class="nNote">
                                <div class="nWarning">
                                   <p><strong>ADVERTENCIA: </strong><?php echo $error;?></p>
                                </div>
                            </div>
                        <?php endif; ?>
            
            <label for="username">Usuario</label>
            <input type="text" name="username" id="username"  value="<?php echo set_value('usuario'); ?>" class="input"/>
            <label for="password">Password</label>
            <input type="password" name="password" id="password" class="input" />
            <input type="submit" value="Entrar" id="entrar" class="boton" />
            </form>
             </div>
    </div>