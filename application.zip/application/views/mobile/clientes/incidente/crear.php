<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php $this->load->view( 'includes/mobile_header' ) ?>
<section id="contacto" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Contacto</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="contacto" autocomplete="off">
        
        	<div data-role="fieldcontain">
               <label for="categorias" class="select">Categorias:</label>
               <select name="categorias" id="categorias">
                  <option value="">Modulo bienestar</option>
                  <option value="">Salud Ocupacional</option>
                  <option value="">Clima Organizacional</option>
                  <option value="">Módulo Jubilados</option>
               </select>
       		</div>
            
            
            <div data-role="fieldcontain">
               <label for="id_subcategoria" class="select">Subcategorias:</label>
               <select name="id_subcategoria" id="id_subcategoria">
                  <option value="">Hoja de vida</option>
                  <option value="">Beneficiarios</option>
                  <option value="">Auxilios</option>
                  <option value="">Plan de actividades</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="id_condicion" class="select">Prioridad:</label>
               <select name="id_condicion" id="id_condicion">
                  <option value="">Seleccione</option>
                  <option value="1">alta</option>
                  <option value="2">media</option>
                  <option value="2">baja</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="id_condicion" class="select">Area:</label>
               <select name="id_condicion" id="id_condicion">
                  <option value="">Seleccione</option>
                  <option value="1">Soporte Tecnico</option>
                  <option value="2">Desarrollo</option>
                  
               </select>
       		</div>
            
        	<div data-role="fieldcontain">
            	<label for="asunto">Asunto:</label>
                <input type="text" id="asunto" name="asunto" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="detalle">Detalle  Incidente</label>
            <textarea name="detalle" id="detalle"><?php echo set_value('detalle');?></textarea>
            </div>
            
           
           
            <input type="submit" value="enviar" id="contacto-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>
</section>

<?php $this->load->view( 'includes/mobile_footer' ) ?>