<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

<section id="cargo" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ver incidencia</h1>
    </header>
    <article data-role="content">
    	<ul data-role="listview" data-split-icon="gear">
            <li>
                <a href="#pagina2">
                    <img src="<?php echo base_url()?>images/alta.png" title="codigo del ticket">
                    <h3><strong>Autor</strong> Todelar F.M.</h3>
                    <p><strong>Subcategoría:</strong> Primas </p>
                    <p><strong>Estado:</strong> Cerrado</p>
                    <p><strong>Causa:</strong> Centro Medico Imbanaco de Cali S.A.</p></p>
                    
                </a>
            </li>
        </ul>
        
    </article>
    <article data-role="content" >
    	<ul data-role="listview">
            <li data-role="list-divider">Detalle</li>
            <li>Verificar el concepto prima de servicios ya que esta tomando menos dias de lo normal, al parcer esta tomando solo un mes. Gracias, Gloria Moreno.</li>
    	</ul>
    </article>
    
    <article data-role="content" >
    	<form action="" method="post" id="cargos" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="detalle">Nota:</label>
                <textarea id="detalle" name="detalle"></textarea>
            </div>
            
             <div data-role="fieldcontain">
               <label for="estado" class="select">Incidencia:</label>
               <select name="estado" id="estado">
                  <option value="">Abiero y sin resolver</option>
                  <option value="">Cerrado y resuelto</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="prioridad" class="select">Prioridad:</label>
               <select name="prioridad" id="prioridad">
                  <option value="">Alta</option>
                  <option value="">Media</option>
                  <option value="">Baja</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="area" class="select">Area:</label>
               <select name="area" id="area">
                  <option value="">Desarrollo</option>
                  <option value="">Soporte</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="causa" class="select">Area:</label>
               <select name="causa" id="causa">
                  <option value="">Error de la aplicación</option>
                  <option value="">Error de Usuario</option>
               </select>
       		</div>
           
           
            <input type="submit" value="enviar" id="cargo-admin" data-icon="check" data-theme="b"/>
            
        </form>
    </article>
    <article data-role="content" >
    	<ul data-role="listview">
            <li data-role="list-divider">Nota</li>
            <li>Se realiza la respectiva verificacion y se encuentra que efectivamente se toma un mes, ser realiza cambio en la funcion prima_var especificando la fecha dada por el usuario desde el 31/12/2010 hasta el 31/05/2011. Se modifica el concepto 41. Se realiza las moficaciones respectivas por medio de Team Vierwer, para que realice el usuario las pruebas. Quedo atenta a los comentarios del usuario
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>ana.cardoza   2011-06-14 13:11:21</strong></li>
    	</ul>
    </article>
    
</section>