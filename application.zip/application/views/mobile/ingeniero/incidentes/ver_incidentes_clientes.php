<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

<section id="cargo" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ver incidencia</h1>
    </header>
    <article data-role="content">
    	<ul data-role="listview" data-split-icon="gear" data-filter="true">
            <li>
                <a href="#pagina2">
                    <img src="<?php echo base_url()?>images/alta.png" title="codigo del ticket">
                    <h3><strong>Fecha:</strong> 13 de septiembre del 2012</h3>
                    <p><strong>Estado:</strong> Pendiente </p>
                    <p><strong>Asunto:</strong>Creacion de conceptos y grupos</p>
                    <p><strong>Empresa:</strong>Centro Medico Imbanaco de Cali S.A.</p></p>
                </a>
                <a href="#ajustes" data-rel="dialog">Ingeniero asignado: Victoria Saavedra Suarez</a>
            </li>
            <li>
                <a href="#pagina2">
                    <img src="<?php echo base_url()?>images/media.png" title="codigo del ticket">
                   <h3><strong>Fecha:</strong> 13 de septiembre del 2012</h3>
                    <p><strong>Estado:</strong> Pendiente </p>
                    <p><strong>Asunto:</strong>Creacion de conceptos y grupos</p>
                    <p><strong>Empresa:</strong>Centro Medico Imbanaco de Cali S.A.</p></p>
                </a>
                <a href="#ajustes" data-rel="dialog">Ingeniero asignado: Victoria Saavedra Suarez</a>
            </li>
            <li>
                <a href="#pagina2">
                    <img src="<?php echo base_url()?>images/baja.png" title="codigo del ticket">
                   <h3><strong>Fecha:</strong> 13 de septiembre del 2012</h3>
                    <p><strong>Estado:</strong> Pendiente </p>
                    <p><strong>Asunto:</strong>Creacion de conceptos y grupos</p>
                    <p><strong>Empresa:</strong>Centro Medico Imbanaco de Cali S.A.</p></p>
                </a>
                <a href="#ajustes" data-rel="dialog">Ingeniero asignado: Victoria Saavedra Suarez</a>
            </li>
        </ul>

    
    </article>
</section>

