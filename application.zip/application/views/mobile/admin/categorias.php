<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="categorias" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Categorias</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="categorias-form" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="categoria">Categorias:</label>
                <input type="text" id="categoria" name="categoria" />
            </div>
           
           
            <input type="submit" value="enviar" id="categoria-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>