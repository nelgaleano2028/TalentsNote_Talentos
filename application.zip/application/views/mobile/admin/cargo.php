<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="cargo" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Cargo</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="cargo" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="cargo">Cargo:</label>
                <input type="text" id="cargo" name="cargo" />
            </div>
           
           
            <input type="submit" value="enviar" id="cargo-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>