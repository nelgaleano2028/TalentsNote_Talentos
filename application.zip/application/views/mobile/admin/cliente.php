<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="cliente" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Cliente</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="cliente" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="empresa">Empresa:</label>
                <input type="text" id="empresa" name="empresa" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="nit">Nit:</label>
            <input type="text" id="nit" name="nit" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="razon">Razon Social:</label>
            <input type="text" id="razon" name="razon" />
            </div>  
           
            <input type="submit" value="enviar" id="cliente-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>