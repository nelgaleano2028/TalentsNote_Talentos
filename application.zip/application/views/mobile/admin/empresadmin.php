<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="empresadmin" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Empresa Administradora</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="empresadmin" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="empresa">Empresa Admin:</label>
                <input type="text" id="empresa" name="empresa" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="nit">Nit:</label>
            <input type="text" id="nit" name="nit" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="tel">Telefono:</label>
            <input type="text" id="tel" name="tel" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="dir">Dirección:</label>
            <input type="text" id="dir" name="dir" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="web">Website:</label>
            <input type="text" id="web" name="web" />
            </div>
            
           
            <input type="submit" value="enviar" id="empresa" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>