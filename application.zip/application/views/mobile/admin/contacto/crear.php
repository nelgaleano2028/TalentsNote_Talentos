<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php $this->load->view( 'includes/mobile_header' ) ?>
<section id="contacto" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Contacto</h1>
    </header>
     <?php $message= $this->session->set_flashdata('message');?>
    <?php if(!empty($message)):?>
    	<!--Notificacion de mensajes-->
        		<div>
                   <?php if( $message['type'] == 'warning' ): ?>
                   <div class="warning">
                       <p><strong>WARNING: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                   <?php if( $message['type'] == 'information' ): ?>
                   <div class="information">
                       <p><strong>INFORMATION: </strong><?php echo $message['text'] ?></p>
                   </div>   
                   <?php endif; ?>
                   <?php if( $message['type'] == 'success' ): ?> 
                   <div class="success">
                       <p><strong>SUCCESS: </strong><?php echo $message['text'] ?></p>
                   </div> 
                   <?php endif; ?> 
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="failure">
                       <p><strong>FAILURE: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
               </div>
    <?php endif;?>
    <?php 
		$error= validation_errors();
		if(!empty($error)):
	?>
    	<!--Notificacion de errores-->
        <?php echo $error;?>
    <?php endif;?>
    <article data-role="content">
    	<form action="#" method="post" name="contacto" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="correo">Correo:</label>
            <input type="text" id="correo" name="correo" />
            </div>  
            
            <div data-role="fieldcontain">
        	<label for="telefono">Telefono:</label>
            <input type="text" id="telefono" name="telefono" />
            </div> 
            
            <div data-role="fieldcontain">
               <label for="id_cliente" class="select">Empresa:</label>
               <select name="id_cliente" id="id_cliente">
                  <option value="">chec</option>
                  <option value="">Centro medico imbanaco</option>
                  <option value="">Todelar</option>
                  <option value="">Epsa</option>
               </select>
       		</div>
           
            <input type="submit" value="enviar" id="contacto-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>
</section>

<?php $this->load->view( 'includes/mobile_footer' ) ?>