<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php $this->load->view( 'includes/mobile_header' ) ?>
<section id="cargo" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ver Contactos</h1>
    </header>
    <article data-role="content">
    	<ul data-role="listview" data-split-icon="gear" data-filter="true">
            <li>
                <a href="#pagina2">
                    <h3><strong>codigo:</strong> 1</h3>
                    <p><strong>Nombre y apellidos:</strong><!--nombre--> German Alberto <!--apellido-->Arabelaez Giraldo</p> 
                    <!--Primo aca se une dos campo el de nombre y apellido-->
                    <p><strong>Empresa:</strong> CHEC</p>
                    
                </a>
                <select>
                	<option>Seleccione</option>
                	<option value="">Editar</option>
                    <option value="">Eliminar</option>
                </select>
            </li>
            <li>
                <a href="#pagina2">
                   <h3><strong>codigo:</strong> 2</h3>
                    <p><strong>area:</strong><!--nombre--> Maria Claudia <!--apellido-->Ocampo Salazar</p>
                    <p><strong>Empresa:</strong> CHEC</p>
                </a>
                <select>
                	<option>Seleccione</option>
                	<option value="">Editar</option>
                    <option value="">Eliminar</option>
                </select>
            </li>
        </ul>

    
    </article>
</section>

<?php $this->load->view( 'includes/mobile_footer' ) ?>