<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php $this->load->view( 'includes/mobile_header' ) ?>
<section id="cargo" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ver incidencia</h1>
    </header>
    <article data-role="content">
    	<ul data-role="listview" data-split-icon="gear">
            <li>
                <a href="#pagina2">
                    <img src="<?php echo base_url()?>images/alta.png" title="codigo del ticket">
                    <h3><strong>Fecha:</strong> 13 de septiembre del 2012</h3>
                    <p><strong>Asunto:</strong> Creacion de conceptos y grupos</p>
                    <p><strong>Empresa:</strong>Todelar F.M.</p>
                </a>
                <a href="#ajustes" data-rel="dialog">Ingeniero asignado: Victoria Saavedra Suarez</a>
            </li>
            <li>
                <a href="#pagina2">
                    <img src="<?php echo base_url()?>images/media.png" title="codigo del ticket">
                    <h3><strong>Fecha:</strong> 13 de septiembre del 2012</h3>
                    <p><strong>Asunto:</strong> Concepto 35 Ausencia no</p>
                    <p><strong>Empresa:</strong> Rfranco America</p>
                </a>
                <a href="#ajustes" data-rel="dialog">Ingeniero asignado: Victoria Saavedra Suarez</a>
            </li>
            <li>
                <a href="#pagina2">
                    <img src="<?php echo base_url()?>images/baja.png" title="codigo del ticket">
                    <h3><strong>Fecha:</strong> 13 de septiembre del 2012</h3>
                    <p><strong>Asunto:</strong> Implementar nomina de florida</p>
                    <p><strong>Empresa:</strong> Hospital Benajamin Barney Gasca</p>
                </a>
                <a href="#ajustes" data-rel="dialog">Ingeniero asignado: Victoria Saavedra Suarez</a>
            </li>
        </ul>

    
    </article>
</section>

<?php $this->load->view( 'includes/mobile_footer' ) ?>
    