<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="usuario" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Usuario</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="cliente" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="usuario">Usuario:</label>
                <input type="text" id="usuario" name="usuario" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="contrasena">Contraseña:</label>
            <input type="password" id="contrasena" name="contrasena" />
            </div>
            
            <div data-role="fieldcontain">
               <label for="empresa" class="select">Empresa:</label>
               <select name="empresa" id="empresa">
                  <option value="">chec</option>
                  <option value="">Centro medico imbanaco</option>
                  <option value="">Todelar</option>
                  <option value="">Epsa</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="ingeniero" class="select">Ingeniero:</label>
               <select name="ingeniero" id="ingeniero">
                  <option value="">rover code</option>
                  <option value="">pacheco simpson</option>
                  <option value="">paco simpson</option>
                  <option value="">memin simpson</option>
               </select>
       		</div>
           
           <div data-role="fieldcontain">
               <label for="perfil" class="select">Perfil:</label>
               <select name="perfil" id="perfil">
                  <option value="">Administrador</option>
                  <option value="">Ingeniero</option>
                  <option value="">Cliente</option>
               </select>
       		</div>
            <input type="submit" value="enviar" id="cliente-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>