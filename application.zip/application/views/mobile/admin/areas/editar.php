<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php $this->load->view( 'includes/mobile_header' ) ?>
<section id="cargo" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Cargo</h1>
    </header>
    <?php $message= $this->session->set_flashdata('message');?>
    <?php if(!empty($message)):?>
    	<!--Notificacion de mensajes-->
        		<div>
                   <?php if( $message['type'] == 'warning' ): ?>
                   <div class="warning">
                       <p><strong>WARNING: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                   <?php if( $message['type'] == 'information' ): ?>
                   <div class="information">
                       <p><strong>INFORMATION: </strong><?php echo $message['text'] ?></p>
                   </div>   
                   <?php endif; ?>
                   <?php if( $message['type'] == 'success' ): ?> 
                   <div class="success">
                       <p><strong>SUCCESS: </strong><?php echo $message['text'] ?></p>
                   </div> 
                   <?php endif; ?> 
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="failure">
                       <p><strong>FAILURE: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
               </div>
    <?php endif;?>
    <?php 
		$error= validation_errors();
		if(!empty($error)):
	?>
    	<!--Notificacion de errores-->
        <?php echo $error;?>
    <?php endif;?>
    <article data-role="content">
    	<form action="<?php base_url()?>areas/editar" method="post" id="cargos" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="nombre_area">Areas:</label>
                <input type="text" id="nombre_area" name="nombre_area" class="required caracter"
                value="<?php echo set_value('nombre_area');?>"/>
            </div>
           
           
            <input type="submit" value="enviar"  data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>
</section>

<?php $this->load->view( 'includes/mobile_footer' ) ?>