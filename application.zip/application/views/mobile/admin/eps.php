<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="eps" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Eps</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="eps" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="eps">Eps:</label>
                <input type="text" id="eps" name="eps" />
            </div>
           
           
            <input type="submit" value="enviar" id="eps-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>