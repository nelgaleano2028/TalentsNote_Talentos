<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="empresadmin" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Empresa Administradora</h1>
    </header>
    <?php $message= $this->session->set_flashdata('message');?>
    <?php if(!empty($message)):?>
    	<!--Notificacion de mensajes-->
        		<div>
                   <?php if( $message['type'] == 'warning' ): ?>
                   <div class="warning">
                       <p><strong>WARNING: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                   <?php if( $message['type'] == 'information' ): ?>
                   <div class="information">
                       <p><strong>INFORMATION: </strong><?php echo $message['text'] ?></p>
                   </div>   
                   <?php endif; ?>
                   <?php if( $message['type'] == 'success' ): ?> 
                   <div class="success">
                       <p><strong>SUCCESS: </strong><?php echo $message['text'] ?></p>
                   </div> 
                   <?php endif; ?> 
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="failure">
                       <p><strong>FAILURE: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
               </div>
    <?php endif;?>
    <?php 
		$error= validation_errors();
		if(!empty($error)):
	?>
    	<!--Notificacion de errores-->
        <?php echo $error;?>
    <?php endif;?>
    <article data-role="content">
    	<form action="#" method="post" name="empresadmin" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="nombre_empresa">Empresa Admin:</label>
                <input type="text" id="nombre_empresa" name="nombre_empresa" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="nit">Nit:</label>
            <input type="text" id="nit" name="nit" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="telefono">Telefono:</label>
            <input type="text" id="telefono" name="telefono" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="direccion">Dirección:</label>
            <input type="text" id="direccion" name="direccion" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="website">Website:</label>
            <input type="text" id="website" name="website" />
            </div>
            
           
            <input type="submit" value="enviar" id="empresa" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>