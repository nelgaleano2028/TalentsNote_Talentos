<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="timeprioridad" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Tiempo de Prioridad</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="timeprioridad-form" autocomplete="off">
           
           <div data-role="fieldcontain">
               <label for="prioridad" class="select">Prioridad:</label>
               <select name="prioridad" id="prioridad">
                  <option value="">alta</option>
                  <option value="">media</option>
                  <option value="">baja</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="cliente" class="select">Cliente:</label>
               <select name="cliente" id="cliente">
                  <option value="">chec</option>
                  <option value="">todelar</option>
                  <option value="">epsa</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
            	<label for="tiempo">Tiempo:</label>
                <input type="text" id="tiempo" name="tiempo" />
            </div>
            <input type="submit" value="enviar" id="timeprioridad-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>
