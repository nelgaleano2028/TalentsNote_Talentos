<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php $this->load->view( 'includes/mobile_header' ) ?>
<section id="cargo" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ver Categorias</h1>
    </header>
    <article data-role="content">
    	<ul data-role="listview" data-split-icon="gear" data-filter="true">
            <li>
                <a href="#pagina2">
                    <h3><strong>codigo:</strong> 1</h3>
                    <p><strong>Cargo:</strong> Ingeniero Soporte</p>
                    
                </a>
                <select>
                	<option>Seleccione</option>
                	<option value="">Editar</option>
                    <option value="">Eliminar</option>
                </select>
            </li>
            <li>
                <a href="#pagina2">
                   <h3><strong>codigo:</strong> 2</h3>
                    <p><strong>Cargo:</strong> Ingeniero desarrollo</p>
                </a>
                <select>
                	<option>Seleccione</option>
                	<option value="">Editar</option>
                    <option value="">Eliminar</option>
                </select>
            </li>
        </ul>

    
    </article>
</section>

<?php $this->load->view( 'includes/mobile_footer' ) ?>