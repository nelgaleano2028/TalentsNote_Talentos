<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="cesantias" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Cesantias</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="cesantias" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="cesantia">cesantias:</label>
                <input type="text" id="cesantia" name="cesantia" />
            </div>
           
           
            <input type="submit" value="enviar" id="cesantia-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>