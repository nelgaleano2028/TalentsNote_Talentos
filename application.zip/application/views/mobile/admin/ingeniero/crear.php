<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php $this->load->view( 'includes/mobile_header' ) ?>
<section id="ingeniero" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Ingeniero</h1>
    </header>
    <?php $message= $this->session->set_flashdata('message');?>
    <?php if(!empty($message)):?>
    	<!--Notificacion de mensajes-->
        		<div>
                   <?php if( $message['type'] == 'warning' ): ?>
                   <div class="warning">
                       <p><strong>WARNING: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                   <?php if( $message['type'] == 'information' ): ?>
                   <div class="information">
                       <p><strong>INFORMATION: </strong><?php echo $message['text'] ?></p>
                   </div>   
                   <?php endif; ?>
                   <?php if( $message['type'] == 'success' ): ?> 
                   <div class="success">
                       <p><strong>SUCCESS: </strong><?php echo $message['text'] ?></p>
                   </div> 
                   <?php endif; ?> 
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="failure">
                       <p><strong>FAILURE: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
               </div>
    <?php endif;?>
    <?php 
		$error= validation_errors();
		if(!empty($error)):
	?>
    	<!--Notificacion de errores-->
        <?php echo $error;?>
    <?php endif;?>
    <article data-role="content">
    	<form action="#" method="post" name="contacto" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="cedula">Cedula:</label>
            <input type="text" id="cedula" name="cedula" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="celular">Celular:</label>
            <input type="text" id="celular" name="celular" />
            </div>  
            
            <div data-role="fieldcontain">
        	<label for="correo">correo:</label>
            <input type="text" id="correo" name="correo" />
            </div> 
            
            <div data-role="fieldcontain">
            <label for="estado_laboral">Estado:</label>
            <select name="estado_laboral" id="estado_laboral" data-role="slider">
                <option value="off">On</option>
                <option value="on">Off</option>
            </select> 
            </div>
           
           <div data-role="fieldcontain">
               <label for="id_eps" class="select">Eps:</label>
               <select name="id_eps" id="id_eps">
                  <option value="">coomeva</option>
                  <option value="">sanitas</option>
                  <option value="">comfenalco</option>
                  <option value="">saludcoop</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="id_pensiones" class="select">Pension:</label>
               <select name="id_pensiones" id="id_pensiones">
                  <option value="">Seguro social</option>
                  <option value="">Proteccion</option>
                  <option value="">Porvenir</option>
                  <option value="">iss</option>
               </select>
       		</div>
            
             <div data-role="fieldcontain">
               <label for="id_cesantias" class="select">Cesantia:</label>
               <select name="id_cesantias" id="id_cesantias">
                  <option value="">Proteccion</option>
                  <option value="">Horizonte</option>
                  <option value="">Porvenir</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="id_cargo" class="select">Cargo:</label>
               <select name="id_cargo" id="id_cargo">
                  <option value="">Ingeniero de soporte</option>
                  <option value="">Ingeniero de desarrollo</option>
               </select>
       		</div>
            <input type="submit" value="enviar" id="contacto-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>
</section>

<?php $this->load->view( 'includes/mobile_footer' ) ?>
