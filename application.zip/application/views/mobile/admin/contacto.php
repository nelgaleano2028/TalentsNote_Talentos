<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="contacto" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Contacto</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="contacto" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="correo">Correo:</label>
            <input type="text" id="correo" name="correo" />
            </div>  
            
            <div data-role="fieldcontain">
        	<label for="tel">Telefono:</label>
            <input type="text" id="tel" name="tel" />
            </div> 
            
            <div data-role="fieldcontain">
               <label for="empresa" class="select">Empresa:</label>
               <select name="empresa" id="empresa">
                  <option value="">chec</option>
                  <option value="">Centro medico imbanaco</option>
                  <option value="">Todelar</option>
                  <option value="">Epsa</option>
               </select>
       		</div>
           
            <input type="submit" value="enviar" id="contacto-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>