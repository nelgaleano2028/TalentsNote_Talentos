<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="Subcategorias" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Subcategorias</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="Subcategorias-form" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="Subcategoria">Subcategorias:</label>
                <input type="text" id="Subcategoria" name="Subcategoria" />
            </div>
            
             <div data-role="fieldcontain">
               <label for="categoria" class="select">Categorias:</label>
               <select name="categoria" id="categoria">
                  <option value="">Hoja de vida</option>
                  <option value="">Beneficiarios</option>
                  <option value="">Auxilios</option>
                  
               </select>
       		</div>
           
           
            <input type="submit" value="enviar" id="Subcategorias-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>