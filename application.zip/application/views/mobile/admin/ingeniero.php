<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="ingeniero" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Ingeniero</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="contacto" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="cedula">Cedula:</label>
            <input type="text" id="cedula" name="cedula" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="celular">Celular:</label>
            <input type="text" id="celular" name="celular" />
            </div>  
            
            <div data-role="fieldcontain">
        	<label for="correo">correo:</label>
            <input type="text" id="correo" name="correo" />
            </div> 
            
            <div data-role="fieldcontain">
            <label for="estado">Estado:</label>
            <select name="estato" id="estado" data-role="slider">
                <option value="off">On</option>
                <option value="on">Off</option>
            </select> 
            </div>
           
           <div data-role="fieldcontain">
               <label for="eps" class="select">Eps:</label>
               <select name="eps" id="eps">
                  <option value="">coomeva</option>
                  <option value="">sanitas</option>
                  <option value="">comfenalco</option>
                  <option value="">saludcoop</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="pension" class="select">Pension:</label>
               <select name="pension" id="pension">
                  <option value="">Seguro social</option>
                  <option value="">Proteccion</option>
                  <option value="">Porvenir</option>
                  <option value="">iss</option>
               </select>
       		</div>
            
             <div data-role="fieldcontain">
               <label for="cesantia" class="select">Cesantia:</label>
               <select name="cesantia" id="cesantia">
                  <option value="">Proteccion</option>
                  <option value="">Horizonte</option>
                  <option value="">Porvenir</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="cargo" class="select">Cargo:</label>
               <select name="cargo" id="cargo">
                  <option value="">Ingeniero de soporte</option>
                  <option value="">Ingeniero de desarrollo</option>
               </select>
       		</div>
            <input type="submit" value="enviar" id="contacto-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>
