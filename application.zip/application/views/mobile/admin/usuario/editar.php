<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php $this->load->view( 'includes/mobile_header' ) ?>
<section id="usuario" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Usuario</h1>
    </header>
     <?php $message= $this->session->set_flashdata('message');?>
    <?php if(!empty($message)):?>
    	<!--Notificacion de mensajes-->
        		<div>
                   <?php if( $message['type'] == 'warning' ): ?>
                   <div class="warning">
                       <p><strong>WARNING: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                   <?php if( $message['type'] == 'information' ): ?>
                   <div class="information">
                       <p><strong>INFORMATION: </strong><?php echo $message['text'] ?></p>
                   </div>   
                   <?php endif; ?>
                   <?php if( $message['type'] == 'success' ): ?> 
                   <div class="success">
                       <p><strong>SUCCESS: </strong><?php echo $message['text'] ?></p>
                   </div> 
                   <?php endif; ?> 
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="failure">
                       <p><strong>FAILURE: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
               </div>
    <?php endif;?>
    <?php 
		$error= validation_errors();
		if(!empty($error)):
	?>
    	<!--Notificacion de errores-->
        <?php echo $error;?>
    <?php endif;?>
    <article data-role="content">
    	<form action="#" method="post" name="cliente" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="usuario">Usuario:</label>
                <input type="text" id="usuario" name="usuario" />
            </div>
            
            <div data-role="fieldcontain">
        	<label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" />
            </div>
            
            <div data-role="fieldcontain">
               <label for="id_contacto" class="select">Contacto:</label>
               <select name="id_contacto" id="id_contacto">
                  <option value="">German Alberto</option>
                  <option value="">Maria Claudia</option>
                  <option value="">Yelitza</option>
                  <option value="">Edwin</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="id_empresa" class="select">Empresa:</label>
               <select name="id_empresa" id="id_empresa">
                  <option value="">chec</option>
                  <option value="">Centro medico imbanaco</option>
                  <option value="">Todelar</option>
                  <option value="">Epsa</option>
               </select>
       		</div>
            
            <div data-role="fieldcontain">
               <label for="id_ingeniero" class="select">Ingeniero:</label>
               <select name="id_ingeniero" id="id_ingeniero">
                  <option value="">rover code</option>
                  <option value="">pacheco simpson</option>
                  <option value="">paco simpson</option>
                  <option value="">memin simpson</option>
               </select>
       		</div>
           
           <div data-role="fieldcontain">
               <label for="id_perfil" class="select">Perfil:</label>
               <select name="id_perfil" id="id_perfil">
                  <option value="">Administrador</option>
                  <option value="">Ingeniero</option>
                  <option value="">Cliente</option>
               </select>
       		</div>
            <input type="submit" value="enviar" id="cliente-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>
 </section>

<?php $this->load->view( 'includes/mobile_footer' ) ?>