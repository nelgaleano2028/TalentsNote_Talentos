<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<section id="conexion" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Conexion</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="conexion-form" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="conexion">Conexion:</label>
                <input type="text" id="conexion" name="conexion" />
            </div>
           
           
            <input type="submit" value="enviar" id="conexion-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>