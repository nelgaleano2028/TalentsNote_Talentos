<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php $this->load->view( 'includes/mobile_header' ) ?>
<section id="Subcategorias" data-role="page" >
	<header data-role="header" data-theme="c">
    	<a href="index"  data-icon="home"  data-iconpos="notext">Home</a>
    	<h1>Ingresar Subcategorias</h1>
    </header>
    <article data-role="content">
    	<form action="#" method="post" name="Subcategorias-form" autocomplete="off">
        	<div data-role="fieldcontain">
            	<label for="opcion">Subcategorias:</label>
                <input type="text" id="opcion" name="opcion" />
            </div>
            
             <div data-role="fieldcontain">
               <label for="relacion" class="select">Categorias:</label>
               <select name="relacion" id="relacion">
                  <option value="">Hoja de vida</option>
                  <option value="">Beneficiarios</option>
                  <option value="">Auxilios</option>
                  
               </select>
       		</div>
           
           
            <input type="submit" value="enviar" id="Subcategorias-admin" data-icon="check" data-theme="b"/>
            
        </form>
    
    </article>
</section>

<?php $this->load->view( 'includes/mobile_footer' ) ?>