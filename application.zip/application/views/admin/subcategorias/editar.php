<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>
<!--content-main-->
<div id="content-main">      
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin"><strong>Editar Subcategoría:</strong></span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank">
        	
             <?php  $error= validation_errors(); ?>
            
            <?php  if( !empty( $error ) ): ?>
            	
                 <div class="nNote">
                        <div class="nWarning">
                           <p><strong>ADVERTENCIA: </strong><?php echo $error;?></p>
                        </div>
                 </div>
            	
            <?php endif; ?>
          
        	<form name="form" action="<?php echo base_url() ?>subcategoria/editar/<?php echo $data[0]['id'] ?>" method="post" id="form">
            	<div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Subcategoria:</div>
                        <input type="text" name="opcion" id="opcion" class="required" value="<?php echo set_value('opcion', $data[0]['opcion']) ?>"/>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">categoria:</div>
                        <select name="relacion" id="relacion" class="required" >
                        	<option value="">Seleccione</option>
                            <?php if( !empty( $categorias ) ): foreach( $categorias as $value ): ?>
                            	<option <?php if( $data[0]['relacion'] == $value['id'] ) echo 'selected="selected"' ?> value="<?php echo $value['id'] ?>"><?php echo $value['opcion'] ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                </div>
                
                <div class="fondo-form">
                    <div class="form-boton ">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                         <input type="reset" class="form-insert" id="reset"  value="Limpiar"/>
                    </div>
                    
                </div>
            	<div class="clear"></div>
                <div class="top-form"></div>
            
            </form>
         
        </div>    
</div>
<!--fin content-main-->