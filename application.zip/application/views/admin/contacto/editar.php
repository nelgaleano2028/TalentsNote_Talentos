<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>

<!--content-main-->
<div id="content-main"> 
        <div class="title-cliente">
        
        <div class="admin">
        	 <span class="user-admin"><strong>Insertar Contacto</strong></span>
        </div>
        
        </div>
        <div class="content-on-blank">
        	
           <?php  $error= validation_errors(); ?>
            
            <?php  if( !empty( $error ) ): ?>
            	
                 <div class="nNote">
                        <div class="nWarning">
                           <p><strong>ADVERTENCIA: </strong><?php echo $error;?></p>
                        </div>
                 </div>
            	
            <?php endif; ?>
            
          
        	<form  action="<?php echo base_url() ?>contacto/editar/<?php echo $data[0]['id_contacto'] ?>" method="post" id="form">
            	<div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Nombre:</div>
                        <input type="text" name="nombre" id="nombre" class="required" value="<?php echo set_value( 'nombre', $data[0]['nombre']) ?>" />
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Apellido:</div>
                        <input type="text" name="apellido" id="apellido" class="required" value="<?php echo set_value( 'apellido', $data[0]['apellido']) ?>" />
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Empresa a la que Pertenece</div>
                        <select name="id_cliente" id="id_cliente" class="required">
                        	<option value="">Seleccione...</option>
                            <?php if( !empty( $cliente ) ): foreach( $cliente as $value ): if( $value['id_cliente'] = $data[0]['id_cliente'] ) $ch = 'selected="selected"';  else $ch = ''; ?>
                           		 <option <?php echo $ch ?>  value="<?php echo $value['id_cliente'] ?>"><?php echo $value['nombre_cliente'] ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Correo:</div>
                        <input type="text" name="correo" id="correo" class="required" value="<?php echo set_value( 'correo', $data[0]['correo']) ?>" />
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Telefono:</div>
                        <input type="text" name="telefono" id="telefono" class="required" value="<?php echo set_value( 'telefono', $data[0]['telefono']) ?>" />
                    </div>
                </div>
                <div class="fondo-form">
                	<!--
                    <div class="form-l formulario">
                    	<div class="label">Movil:</div>
                        <input type="text" name="movil" />
                    </div>
                    -->
                    <div class="clear"></div>
                    <div class="form-boton">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                    </div>
                </div>
            	
            
            </form>
         
        </div>    
</div>
<!--fin content-main-->