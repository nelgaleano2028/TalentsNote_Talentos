<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>
<!--content-main-->
<div id="content-main">      
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin"><strong>Editar Ingeniero:</strong></span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank">
        	
            <?php  $error= validation_errors(); ?>
            
            <?php  if( !empty( $error ) ): ?>
            	
                 <div class="nNote">
                        <div class="nWarning">
                           <p><strong>ADVERTENCIA: </strong><?php echo $error;?></p>
                        </div>
                 </div>
            	
            <?php endif; ?>
            
            <form  action="<?php echo base_url() ?>ingeniero/editar/<?php echo $id ?>" method="post" id="form">
            	<div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Nombre:</div>
                        <input type="text" name="nombre" id="nombre" class="required" value="<?php echo set_value('nombre', $data[0]['nombre']) ?>"/>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Cedula:</div>
                        <input type="text" name="cedula" id="cedula" class="required" value="<?php echo set_value('cedula', $data[0]['cedula']) ?>"/>
                    </div>
                </div>
                
                 <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Celular:</div>
                        <input type="text" name="celular" id="celular" class="required" value="<?php echo set_value('celular', $data[0]['celular']) ?>"/>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Correo:</div>
                        <input type="text" name="correo" id="correo" class="required" value="<?php echo set_value('correo', $data[0]['correo']) ?>"/>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Estado Laboral:</div>
                        <select name="estado_laboral" id="estado_laboral" class="required" >
                        	<option value="">Seleccione</option>
                            <option value="Activo" <?php if( $data[0]['estado_laboral'] == 'Activo' ) echo 'selected="selected"' ?>>Activo</option>
                            <option value="Inactivo" <?php if( $data[0]['estado_laboral'] == 'Inactivo' ) echo 'selected="selected"' ?>>Inactivo</option>
                        </select>
                    </div>
                    
                    <div class="form-l formulario">
                    	<div class="label">Eps:</div>
                        <select name="id_eps" id="id_eps" class="required" >
                        	<option value="">Seleccione</option>
                        	<?php if( !empty( $eps ) ): foreach( $eps as $value ): ?>
                            	<option <?php if( $data[0]['id_eps'] == $value['id_eps'] ) echo 'selected="selected"' ?> value="<?php echo $value['id_eps'] ?>"><?php echo $value['nombre_eps'] ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                </div>
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Pension:</div>
                        <select name="id_pensiones" id="id_pensiones" class="required" >
                        	<option value="">Seleccione</option>
                            <?php if( !empty( $pension ) ): foreach( $pension as $value ): ?>
                            	<option <?php if( $data[0]['id_pensiones'] == $value['id_pensiones'] ) echo 'selected="selected"' ?> value="<?php echo $value['id_pensiones'] ?>"><?php echo $value['nombre_pensiones'] ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    
                    <div class="form-l formulario">
                    	<div class="label">Cesantia:</div>
                        <select name="id_cesantias" id="id_cesantias" class="required" >
                        	<option value="">Seleccione</option>
                            <?php if( !empty( $cesantia ) ): foreach( $cesantia as $value ): ?>
                            	<option <?php if( $data[0]['id_cesantias'] == $value['id_cesantias'] ) echo 'selected="selected"' ?> value="<?php echo $value['id_cesantias'] ?>"><?php echo $value['nombre_cesantias'] ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Cargo:</div>
                        <select name="id_cargo" id="id_cargo" class="required" >
                        	<option value="">Seleccione</option>
                            <?php if( !empty( $cargo ) ): foreach( $cargo as $value ): ?>
                            	<option <?php if( $data[0]['id_cargo'] == $value['id_cargo'] ) echo 'selected="selected"' ?> value="<?php echo $value['id_cargo'] ?>"><?php echo $value['nombre_cargo'] ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    
                    <div class="form-l formulario">
                    	<div class="label">Área:</div>
                        <select name="id_area" id="id_area" class="required" >
                        	<option value="">Seleccione</option>
                            <?php if( !empty( $area ) ): foreach( $area as $value ): ?>
                                <option <?php if( $data[0]['id_area'] == $value['id_area'] ) echo 'selected="selected"' ?> value="<?php echo $value['id_area'] ?>"><?php echo $value['nombre_area'] ?></option>
							<?php endforeach; endif; ?>
                        </select>
                    </div>
                    
                    <div class="clear"></div>
                    <div class="form-boton">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                        <input type="reset" id="reset" class="form-insert"  value="Limpiar"/>
                    </div>
                </div>
                <div class="clear"></div>
                <div class="top-form"></div>
                
            
            	
            </form>
         
        </div>    
</div>
<!--fin content-main-->
