<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>

<!--content-main-->
<div id="content-main">      
        <div class="title-cliente"><span><strong>Ver Incidencias nombre de la empresa</strong> </span></div>
        <div class="content-on-blank-table">
        	<!--table-->
        	<div class="table">
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
                <thead>
                    <tr>
                        <th>Codigo</th>
                        <th>Empresa Administradora</th>
                        <th>Nit</th>
                        <th>Telefono</th>
                        <th>Dirección</th>
                        <th>Website</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                        
                        
                    </tr>
                </thead>
                <tbody>
                    <tr >
                        <td>Trident</td>
                        <td>Internet
                             Explorer 4.0</td>
                        <td>830-071958-5</td>
                        <td>371-7611</td>
                        <td>avenida 2da EN # 40-73</td>
                        <td>www.talentsw.com</td>
                        <td>Editar</td>
                        <td>Eliminar</td>
                        
                        
                    </tr>
                    <tr >
                        <td>Trident</td>
                        <td>Internet
                             Explorer 5.0</td>
                          <td>830-071958-5</td>
                        <td>371-7611</td>
                        <td>avenida 2da EN # 40-73</td>
                        <td>www.talentsw.com</td>
                         <td>Editar</td>
                        <td>Eliminar</td>
                       
                    </tr>
                    <tr >
                        <td>Trident</td>
                        <td>Internet
                             Explorer 5.5</td>
                             
                         <td>830-071958-5</td>
                        <td>371-7611</td>
                        <td>avenida 2da EN # 40-73</td>
                        <td>www.talentsw.com</td>
                        <td>Editar</td>
                        <td>Eliminar</td>
                        
                    </tr>
                    <tr >
                        <td>Trident</td>
                        <td>Internet
                             Explorer 6</td>
                         <td>830-071958-5</td>
                        <td>371-7611</td>
                        <td>avenida 2da EN # 40-73</td>
                        <td>www.talentsw.com</td>
                        <td>Editar</td>
                        <td>Eliminar</td>
                        
                    </tr>
                    <tr >
                        <td>Trident</td>
                        <td>Internet Explorer 7</td>
                        <td>830-071958-5</td>
                        <td>371-7611</td>
                        <td>avenida 2da EN # 40-73</td>
                        <td>www.talentsw.com</td>
                        <td>Editar</td>
                        <td>Eliminar</td>
       
                    </tr>
                    
                </tbody>
			</table>
            </div>
        	<!--Fin table-->
            
         
        </div>    
</div>