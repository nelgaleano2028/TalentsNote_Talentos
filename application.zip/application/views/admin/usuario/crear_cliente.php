<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>
<!--content-main-->
<div id="content-main">    
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin">Ingresar Usuario:</span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank">
        	
             <?php  $error= validation_errors(); ?>
            
            <?php  if( !empty( $error ) ): ?>
            	
                 <div class="nNote">
                        <div class="nWarning">
                           <p><strong>ADVERTENCIA: </strong><?php echo $error;?></p>
                        </div>
                 </div>
            	
            <?php endif; ?>
          
        	<form action="<?php echo base_url() ?>usuario/crear_cliente" method="post" id="form" autocomplete="off">
            	<div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Usuario</div>
                        <input type="text" name="Usuario" id="Usuario" class="required" />
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Contraseña</div>
                        <input type="password" name="password" id="password" class="required" />
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Nombre Contacto</div>
                        <select name="id_contacto" id="id_contacto" class="required" >
                        	<option value="">Seleccione</option>
                            <?php if( !empty( $contacto ) ): foreach( $contacto as $value ): ?>
                            	<option value="<?php echo $value['id_contacto'] ?>"><?php echo $value['nombre'] ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                </div>

                    <input type="hidden" name="id_perfil"  value="3"  />
                   	<input type="hidden" name="estado" value="1" id="estado" />
               
                <div class="fondo-form">
                    <div class="form-boton">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                        <input type="reset" class="form-insert" id="reset"  value="Limpiar"/>
                    </div>
                    
                </div>
            
            
            </form>
         
        </div>    
</div>
<!--fin content-main-->