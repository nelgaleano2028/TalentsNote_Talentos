<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>
<!--content-main-->
<div id="content-main">    
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin">Editar Usuario:</span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank">
        	
             <?php  $error= validation_errors(); ?>
            
            <?php  if( !empty( $error ) ): ?>
            	
                 <div class="nNote">
                        <div class="nWarning">
                           <p><strong>ADVERTENCIA: </strong><?php echo $error;?></p>
                        </div>
                 </div>
            	
            <?php endif; ?>
          
        	<form action="<?php echo base_url() ?>usuario/editar/<?php echo $data[0]['id_usuario']; ?>" method="post" id="form">
            	<div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Usuario</div>
                        <input type="text" name="Usuario" id="Usuario" class="required" value="<?php echo set_value('Usuario', $data[0]['Usuario']) ?>"/>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Contraseña</div>
                        <input type="password" name="password" id="password" class="required" value="<?php echo set_value('password', $data[0]['contraseña']) ?>"/>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Nombre Contacto</div>
                        <select name="id_contacto" id="id_contacto"  >
                        	<option value="">Seleccione</option>
                            <?php if( !empty( $contacto ) ): foreach( $contacto as $value ): ?>
                            	<option <?php if( $data[0]['id_contacto'] == $value['id_contacto'] ) echo 'selected="selected"' ?> value="<?php echo $value['id_contacto'] ?>"><?php echo $value['nombre'] ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                </div>
                
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Ingeniero</div>
                        <select name="id_ingeniero" id="id_ingeniero"  >
                        	<option value="">Seleccione</option>
                            <?php if( !empty( $ingenieros ) ): foreach( $ingenieros as $value ): ?>
                            	<option <?php if( $data[0]['id_ingeniero'] == $value['id_ingeniero'] ) echo 'selected="selected"' ?> value="<?php echo $value['id_ingeniero'] ?>"><?php echo $value['nombre'] ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Tipo Perfil</div>
                        <select name="id_perfil" id="id_perfil" class="required">
                        	<option value="">Seleccione</option>
                            <?php if( !empty( $perfiles ) ): foreach( $perfiles as $value ): ?>
                            	<option <?php if( $data[0]['id_perfil'] == $value['id_perfil'] ) echo 'selected="selected"' ?> value="<?php echo $value['id_perfil'] ?>"><?php echo $value['nombre_perfil'] ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    
                    <div class="form-l formulario">
                    	<div class="label">Estado</div>
                        <select name="estado" id="estado" class="required">
                        	<option value="">Seleccione</option>
                            <option value="1">Activo</option>
                            <option value="0">Inactivo</option>
                        </select>
                    </div>
                </div>
                <div class="fondo-form">
                    <div class="form-boton ">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                        <input type="reset" class="form-insert" id="reset"  value="Limpiar"/>
                    </div>
                    
                </div>
            
            
            </form>
         
        </div>    
</div>
<!--fin content-main-->