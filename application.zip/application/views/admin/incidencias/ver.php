<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>
<!--content-main-->
<div id="content-main">      
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin"><strong>Incidencias:</strong></span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank-table">
        	
            <?php $message = $this->session->flashdata( 'message' ); ?>
      
             <?php if( !empty( $message ) ): ?>
                   
              <!-- Notification messages -->
               <div class="nNote">
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="nFailure">
                       <p><strong>ERROR: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
               	  
                   <?php if( $message['type'] == 'success' ): ?>
                   <div class="nSuccess">
                       <p><strong>Correcto: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                  
               </div>
              
              <?php endif; ?>
            
            <!--table-->
        	<div class="table_incidente">
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
                <thead>
                    <tr>
                        <th>Codigo</th>
                        <th>Estado</th>
                        <th>Cliente</th>
                        <th>Ingeniero</th>
                        <th>Prioridad</th>
                        <th>Área</th>
                        <th>Asunto</th>
                        <th>Fecha</th>
                        <th>Fecha Final</th>
                    </tr>
                </thead>
                <tbody>
                
                <?php if( !empty( $data ) ): foreach( $data as $value ): ?>
                    <tr >
                        <td><?php echo $value['id_incidencia'] ?></td>
                        <td>
							<?php 
								if( $value['id_estado'] == 1 ) echo 'Abierto';
								if( $value['id_estado'] == 2 ) echo 'Cerrado';
							?>
                        </td>
                        <td><?php echo $value['cliente'] ?></td>
                        <td><?php echo $value['ingeniero'] ?></td>
                        <td>
							<?php 
								if( $value['id_condicion'] == 1 ) echo 'Alta';
								if( $value['id_condicion'] == 2 ) echo 'Media';
								if( $value['id_condicion'] == 3 ) echo 'Baja';
							 ?>
                        </td>
                        <td><?php echo $value['area'] ?></td>
                        <td class="center"><?php echo anchor( '/incidencias/crear/'.$value['id_incidencia'], $value['asunto'] )?></td>
                        <td><?php echo $value['fecha'] ?></td>
                        <td><?php echo $value['fecha_final'] ?></td>
                        
                    </tr>
                
                <?php endforeach; endif; ?>
                    
                </tbody>
                
                <tfoot>
                    <tr>
                        <th>Codigo</th>
                        <th>Estado</th>
                        <th>Cliente</th>
                        <th>Ingeniero</th>
                        <th>Prioridad</th>
                        <th>Área</th>
                        <th>Asunto</th>
                        <th>Fecha</th>
                        <th>Fecha Final</th>
                    </tr>
                </tfoot>
                
			</table>
            </div>
        	<!--Fin table-->
            
         
        </div>    
</div>
<!--fin content-main-->