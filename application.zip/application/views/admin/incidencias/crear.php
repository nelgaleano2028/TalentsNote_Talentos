<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>
<!--content-main-->
<div id="content-main"> 
        <div class="title-cliente">
       		 <div class="admin">
            	 <span class="user-admin"><strong>Incidencias:</strong></span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank">
        	<!--table-->
        	<div class="table">
            
            	<div class="fondo-form">
                        <div class="form-l">
                            <div class="label-f"><span class="etiqueta-f">Codigo:</span> <span class="parf-f"><?php echo $incidencia[0]['id_incidencia'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Estado:</span> <?php echo $incidencia[0]['estado'] ?></div>
                            <div class="label-f"><span class="etiqueta-f">Asunto:</span><span class="parf-f"> <?php echo $incidencia[0]['asunto'] ?> </span></div>
                           	 <?php
							$fecha=substr($incidencia[0]['fecha'], 0, -9);
                            $fecha = explode( '-', $fecha );
							$fecha = $fecha[2].'-'.$fecha[1].'-'.$fecha[0];
							?>
                            <div class="label-f"><span class="etiqueta-f">Fecha:</span> <span class="parf-f"><?php echo $fecha; ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Cliente:</span> <span class="parf-f"><?php echo $incidencia[0]['cliente'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Subcategoría:</span> <span class="parf-f"><?php echo $incidencia[0]['subcategoria'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Prioridad:</span> <?php echo $incidencia[0]['prioridad'] ?></div>
                            <div class="label-f"><span class="etiqueta-f">Causa:</span> <span class="parf-f"><?php echo $incidencia[0]['causa'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Ingeniero:</span> <span class="parf-f"><?php echo $incidencia[0]['nombre_ingeniero'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Ingeniero Usuario:</span> <span class="parf-f"><?php echo $incidencia[0]['usuario'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Detalle:</span> <span class="parf-f"><?php echo $incidencia[0]['detalle'] ?></span>
                            	<div class="espacio"></div>
                            </div>
  
                        </div>
                       
                        
               		</div> 
                 <form method="post" action="<?php echo base_url() ?>incidencias/crear/<?php echo $incidencia[0]['id_incidencia'] ?>" name="formincidente" id="formincidente">
                 
                 	<div class="fondo-form">
                        <div class="form-l">
                            <div class="label-c"><span class="etiqueta-f">Notas:</span></div>
                           
                        </div>
               		</div>
                    
                    <div class="fondo-form">
                        <div class="form-center formulario">
                           <textarea id="notas" name="notas" class="required"></textarea>
                           
                        </div>
               		</div>
                    
                     
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label"><span class="etiqueta-f">Actualizar Estado Incidencia:</span></div>
                        <select name="id_estado" id="id_estado"  >
                        	<option value="<?php echo $incidencia[0]['id_estado'];?>" selected="selected"><?php echo $incidencia[0]['estado'];?></option>
                            <?php if( !empty( $estado ) ): foreach( $estado as $value ): ?>
                            	
                                	 <option value="<?php echo $value['id_estado'] ?>"><?php echo $value['nombre_estado'] ?></option>
                               	
							<?php endforeach; endif; ?>

                        </select>
                    </div>
                    
                    <div class="form-l formulario">
                    	<div class="label"><span class="etiqueta-f">Actualizar Prioridad:</span></div>
                        <select name="id_condicion" id="id_condicion">       
                            <option value="<?php echo $incidencia[0]['id_prioridad'];?>" selected="selected"><?php echo $incidencia[0]['prioridad'];?></option>
                            <option value="1">Alta</option>
                            <option value="2">Media</option>
                            <option value="3">Baja</option>
                        </select>
                    </div>
                    
                   
                </div>
                
                <div class="fondo-form">
                	
                     <div class="form-l formulario">
                    	<div class="label"><span class="etiqueta-f">Actualizar Area:</span></div>
                        <select name="id_area" id="id_area"  >
                        	<option value="">Seleccione</option>
                            <?php if( !empty( $areas ) ): foreach( $areas as $value ): ?>
                            	<option  value="<?php echo $value['id_area'] ?>"><?php echo $value['nombre_area'] ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    	</div> 
                    <div class="form-l formulario">
                    	<div class="label"><span class="etiqueta-f">Ingeniero:</span></div>
                        <select name="id_ingeniero" id="id_ingeniero">
                        	
                        </select>   
                    </div>
                    <div class="clear"></div>
                    <div class="form-boton">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                        <input type="reset" id="reset" class="form-insert"  value="Limpiar"/>
                    </div>
                </div>
                
                
                 
                 </form>
                 <div class="clear"></div>
                 <div class="separar"></div>
                 
               

                 <div class="clear"></div>
                <div class="top-form"></div>
    	
            </div>
            <!--table-->
        </div>    
</div>
<!--fin content-main-->

