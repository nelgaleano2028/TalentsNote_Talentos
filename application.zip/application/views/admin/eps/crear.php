<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>
 <!--content-main-->
<div id="content-main">     
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin"><strong>Ingresar Eps:</strong></span>
                 
            	
            </div>
         </div>
        
        
        <?php  $error= validation_errors(); ?>
            
            <?php  if( !empty( $error ) ): ?>
            	
                 <div class="nNote">
                        <div class="nWarning">
                           <p><strong>ADVERTENCIA: </strong><?php echo $error;?></p>
                        </div>
                 </div>
            	
            <?php endif; ?>
        
        <div class="content-on-blank">
        	<form  action="<?php echo base_url() ?>eps/crear" method="post" id="form">
            	<div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Empresa Eps:</div>
                        <input type="text" name="nombre_eps" id="nombre_eps" class="required" 
                        value="<?php echo set_value('nombre_eps'); ?>"/>
                    </div>
                </div>
                
                <div class="fondo-form">
                    <div class="form-boton ">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                        <input type="reset" id="reset" class="form-insert"  value="Limpiar"/>
                    </div>
                    
                </div>
                <div class="clear"></div>
                <div class="top-form"></div>
            </form>
        </div>    
</div>
<!--fin content-main-->

