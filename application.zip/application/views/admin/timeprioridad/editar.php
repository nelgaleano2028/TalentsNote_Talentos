<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>
<!--content-main-->
<div id="content-main">      
        <div class="title-cliente"><span><strong>Definir Tiempo de Prioridad</strong></span></div>
        <div class="content-on-blank">
        	
          
        	<form name="form" action="<?php echo base_url() ?>tiempoprioridad/editar/<?php echo $data[0]['id_tiempoprioridad']?>" method="post" id="form">
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Prioridad</div>
                        <select name="id_condicion" id="id_condicion" class="required" >
                        	<option value="">Seleccione</option>
                            <option value="1" <?php if( $data[0]['id_condicion'] == 1 ) echo 'selected="selected"' ?> >Alta</option>
                            <option value="2" <?php if( $data[0]['id_condicion'] == 2 ) echo 'selected="selected"' ?>>Media</option>
                            <option value="3" <?php if( $data[0]['id_condicion'] == 3 ) echo 'selected="selected"' ?>>Baja</option>
                        </select>
                    </div>
                </div>
                
                 <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Cliente</div>
                        <select name="id_cliente" id="id_cliente" class="required" >
                        	<option value="">Seleccione</option>
                         	<?php if( !empty( $cliente ) ): foreach( $cliente as $value ): ?>
                            	<option <?php if( $data[0]['id_cliente'] == $value['id_cliente'] ) echo 'selected="selected"' ?> value="<?php echo  $value['id_cliente']?>"><?php echo  $value['nombre_cliente']?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Definir Tiempo de Prioridad (en horas):</div>
                        <input type="text" name="horas" id="horas" class="required" value="<?php echo  $data[0]['horas'] ?>" />
                    </div>
                </div>
                
                <div class="fondo-form">
                    <div class="form-boton">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                        <input type="reset" class="form-insert"  value="Limpiar"/>
                    </div>
                    
                </div>
            	<div class="clear"></div>
                <div class="top-form"></div>
            
            </form>
         
        </div>    
</div>
<!--fin content-main-->