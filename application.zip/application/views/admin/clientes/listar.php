<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>

<!--content-main-->
<div id="content-main">      
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin"><strong>Nuestros Clientes:</strong></span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank-table">
        	<!--table-->
        	<div class="table_incidente">
            
            <?php $message = $this->session->flashdata( 'message' ); ?>
      
             <?php if( !empty( $message ) ): ?>
                   
              <!-- Notification messages -->
               <div class="nNote">
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="nFailure">
                       <p><strong>ERROR: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
               	  
                   <?php if( $message['type'] == 'success' ): ?>
                   <div class="nSuccess">
                       <p><strong>CORRECTO: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                  
               </div>
              
              <?php endif; ?>
           
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
                <thead>
                    <tr>
                        <th>Codigo</th>
                        <th>Cliente</th>
                        <th>Nit</th>
                        <th>Razon Social</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                        
                        
                    </tr>
                </thead>
                <tbody>
                  
                  	<?php if( !empty( $data ) ):  foreach( $data as $value ): ?>
                   
                   <tr >
                        <td><?php echo $value['id_cliente'] ?></td>
                        <td><?php echo $value['nombre_cliente'] ?></td>
                        <td><?php echo $value['nit'] ?></td>
                        <td><?php echo $value['razon_social'] ?></td>
                        <td class="center"><a href="<?php echo base_url() ?>clientes/editar/<?php echo $value['id_cliente']?>" title="Editar elemento" >
                        <img src="<?php echo base_url()?>images/editar.png" width="20" height="20" title="Editar elemento" alt="editar"/></a>
                        </td>
                        <td class="center"><a href="<?php echo base_url() ?>clientes/eliminar/<?php echo $value['id_cliente']?>" onclick="javascript: if( !confirm( 'Quiere eliminar este elemento ?' ) ) return false;">
                        <img src="<?php echo base_url()?>images/eliminar.png" width="20" height="20" title="Eliminar elemento" alt="editar"/>	</a>
                        </td>
                        
                    </tr>
                    
                    <?php endforeach; endif; ?> 
                    
                    <tr >
                        <td>Trident</td>
                        <td>Internet
                             Explorer 4.0</td>
                         <td>890307200</td>
                         <td>Centro Medico Imbanaco de Cali S.A.</td>
                        <td>Editar</td>
                        <td>Eliminar</td>
                        
                        
                    </tr>
                                       
                </tbody>
			</table>
            </div>
        	<!--Fin table-->
            
         
        </div>    
</div>
