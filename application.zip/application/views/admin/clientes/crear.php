<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>

<!--content-main-->
<div id="content-main"> 
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin"><strong>Nuevo Cliente:</strong></span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank">
        	
            <?php  $error= validation_errors(); ?>
            
            <?php  if( !empty( $error ) ): ?>
            	
                 <div class="nNote">
                        <div class="nWarning">
                           <p><strong>ADVERTENCIA: </strong><?php echo $error;?></p>
                        </div>
                 </div>
            	
            <?php endif; ?>
          
        	<form action="<?php echo base_url() ?>clientes/crear" method="post" id="form">
            	<div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label"><label>Nombre del Cliente:</label></div>
                        <input type="text" name="nombre_cliente" id="nombre_cliente" class="required alphanumeric" value="<?php echo set_value('nombre_cliente')?>" />
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Nit del Cliente:</div>
                        <input type="text" name="nit" id="nit" class="required nit" value="<?php echo set_value('nit')?>"/>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Razon Social:</div>
                        <input type="text" name="razon_social" id="razon_social" class="required alphanumeric" value="<?php echo set_value('razon_social')?>"/>
                    </div>
                    <div class="clear"></div>
                    <div class="form-boton">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                        <input type="reset" id="reset" class="form-insert"  value="Limpiar"/>
                    </div>
                </div>
                <div class="clear"></div>
                <div class="top-form"></div>
            
            
            </form>
         
        </div>    
</div>
<!--fin content-main--> 

