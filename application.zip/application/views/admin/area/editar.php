<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>


<!--content-main-->
<div id="content-main"> 
       
        <div class="admin">
            	 <span class="user-admin"><strong>Editar Área:</strong></span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank">
        	
			<?php  $error= validation_errors(); ?>
            
            <?php  if( !empty( $error ) ): ?>
            	
                 <div class="nNote">
                        <div class="nWarning">
                           <p><strong>ADVERTENCIA: </strong><?php echo $error;?></p>
                        </div>
                 </div>
            	
            <?php endif; ?>
            
        	<form action="<?php echo base_url()?>area/editar/<?php echo $data[0]['id_area'] ?>" method="post" id="form">
            	<div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Cargo</div>
                        <input type="text" id="nombre_area" name="nombre_area" class="required alphanumeric" 
                        value="<?php echo set_value('nombre_area',$data[0]['nombre_area'])?>"/>
                       
                    </div>
                </div>
                
                <div class="fondo-form">
                    <div class="form-boton ">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                        <input type="reset" id="reset" class="form-insert" value="Limpiar" title="Limpiar el formulario" onclick="document.registro.reset();"/>
                    </div>
                    
                </div>
                <div class="clear"></div>
                <div class="top-form"></div>
            </form>
        </div>    
</div>
<!--fin content-main-->

