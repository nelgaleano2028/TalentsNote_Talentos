<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
$this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
$this->output->set_header( "Pragma: no-cache" ); 
?>
	
    <?php $message = $this->session->flashdata( 'message' ); ?>
       
       <?php if( !empty( $message ) ): ?>
            
       <!-- Notification messages -->
        <div class="pt20">
            <?php if( $message['type'] == 'warning' ): ?>
            <div class="nNote nWarning hideit">
                <p><strong>WARNING: </strong><?php echo $message['text'] ?></p>
            </div>
            <?php endif; ?>
            <?php if( $message['type'] == 'information' ): ?>
            <div class="nNote nInformation hideit">
                <p><strong>INFORMATION: </strong><?php echo $message['text'] ?></p>
            </div>   
            <?php endif; ?>
            <?php if( $message['type'] == 'success' ): ?> 
            <div class="nNote nSuccess hideit">
                <p><strong>SUCCESS: </strong><?php echo $message['text'] ?></p>
            </div> 
            <?php endif; ?> 
            <?php if( $message['type'] == 'failure' ): ?>
            <div class="nNote nFailure hideit">
                <p><strong>FAILURE: </strong><?php echo $message['text'] ?></p>
            </div>
            <?php endif; ?>
        </div>
       
       <?php endif; ?>

<!--content-main-->
<div id="content-main2"> 
        <div class="title-cliente">
        <div class="ingeniero">
            	 <span class="user-admin"><strong>Bienvenido Ingeniero:</strong></span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank">
        	<!--table-->
        	<div class="table_incidente">
            	<table class="incidencias">
                	<tr>
                    	<th>Ingeniero</th>
                        <th>Cedula</th>
                        <th>Celular</th>
                        <th>Correo</th>
                        <th>Estado</th>
                        <th>Cesantias</th>
                        <th>Pensiones</th>
                        <th>Eps</th>
                        <th>Cargo</th>
                    </tr>
                 
                    <tr>
                        <td><?php echo $ingeniero[0]['nombre'] ?></td>
                        <td><?php echo $ingeniero[0]['cedula'] ?></td>
                        <td><?php echo $ingeniero[0]['celular'] ?></td>
                        <td class="center"><?php echo $ingeniero[0]['correo'] ?></td>
                        <td class="center"><?php echo $ingeniero[0]['estado_laboral'] ?></td>
                        <td class="center"><?php echo $ingeniero[0]['censantias'] ?></td>
                        <td class="center"><?php echo $ingeniero[0]['pensiones'] ?></td>
                        <td class="center"><?php echo $ingeniero[0]['eps'] ?></td>
                        <td class="center"><?php echo $ingeniero[0]['cargo'] ?></td>
                        
                    </tr>
                   
                </table>
                <div class="separar"></div>
              
    	
            </div>
            <!--table-->
        </div>    
</div>
<!--fin content-main-->

