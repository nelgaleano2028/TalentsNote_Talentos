<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?php
$this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
$this->output->set_header( "Pragma: no-cache" ); 
?>


	   <?php $message = $this->session->flashdata( 'message' ); ?>
       
       <?php if( !empty( $message ) ): ?>
            
       <!-- Notification messages -->
        <div class="pt20">
            <?php if( $message['type'] == 'warning' ): ?>
            <div class="nNote nWarning hideit">
                <p><strong>WARNING: </strong><?php echo $message['text'] ?></p>
            </div>
            <?php endif; ?>
            <?php if( $message['type'] == 'information' ): ?>
            <div class="nNote nInformation hideit">
                <p><strong>INFORMATION: </strong><?php echo $message['text'] ?></p>
            </div>   
            <?php endif; ?>
            <?php if( $message['type'] == 'success' ): ?> 
            <div class="nNote nSuccess hideit">
                <p><strong>SUCCESS: </strong><?php echo $message['text'] ?></p>
            </div> 
            <?php endif; ?> 
            <?php if( $message['type'] == 'failure' ): ?>
            <div class="nNote nFailure hideit">
                <p><strong>FAILURE: </strong><?php echo $message['text'] ?></p>
            </div>
            <?php endif; ?>
        </div>
       
       <?php endif; ?>


<!--content-main-->
<div id="content-main2"> 
        <div class="title-cliente">
            <div class="ingeniero">
            	 <span class="user-admin"><strong>Bienvenido Administrador</strong></span>
                 
            	
            </div>
        </div>
        <div class="content-on-blank">
        	<!--table-->
        	<div class="table">
            	<table class="incidencias">
                	<tr>
                    	
                        <th>Empresa:</th>
                        <th>Nit:</th>
                        <th>Telefono:</th>
                        <th>Direccion:</th>
                        <th>Website:</th>
                        	
                    </tr>
                 
                    <tr>
                        
                        <td>Talentos y Tecnologia</td>
                        <td>830-071958-5</td>
                        <td>371-7611</td>
                        <td class="center">avenida 2da EN # 40-73</td>
                        <td class="center">www.talentsw.com</td>
                        	
                        
                    </tr>
                   
                </table>
                <div class="separar"></div>
              
    	
            </div>
            <!--table-->
        </div>    
</div>
<!--fin content-main-->
