<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>

<!--content-main-->
<div id="content-main"> 
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin"><strong>Nuevo Incidente:</strong></span>

            </div>
         </div>
         
          <?php $message = $this->session->flashdata( 'message' ); ?>
      
             <?php if( !empty( $message ) ): ?>
                   
              <!-- Notification messages -->
               <div class="nNote">
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="nFailure">
                       <p><strong>ERROR: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
               </div>
                <?php endif; ?>
        <div class="content-on-blank">
        	<form action="<?php echo base_url() ?>clientes/nuevo_incidente" id="formincidente" method="post" enctype="multipart/form-data">
            	<div class="fondo-form">
                	<div class="form-l formulario">
                 	<div class="label-n"><span class="etiqueta-n">Categorias:</span></div>
                    <select name="categorias" id="categorias" class="required">
                    	<option value="">Seleccione</option>
                        
                        <?php if( !empty( $categorias ) ): foreach( $categorias as $value ): ?>
                        	<option value="<?php echo $value['id']?>"><?php echo $value['opcion']?></option>
                        <?php endforeach; endif; ?>
                        
                    </select>
                    </div>
                    <div class="form-r formulario">
                    	<div class="label-n"><span class="etiqueta-n">Subcategorias:</span></div>
                    	<select name="id_subcategoria" id="id_subcategoria" class="required">
                        
                        </select>
                    </div>
                </div>
                <div class="fondo-form">
                	<div class="form-l formulario">
                	<div class="label-n"><span class="etiqueta-n">Prioridad:</span></div>
                    <select name="id_condicion" id="id_condicion" class="required">
                    	<option value="">Seleccione</option>
                    	<option value="1">alta</option>
                        <option value="2">media</option>
                        <option value="2">baja</option>
                    </select>
                	</div>
                    
                   <div class="form-r formulario">
                    	<div class="label-n"><span class="etiqueta-n">Area:</span></div>
                    	<select name="id_area" id="id_area" class="required">
                        
                    	<option value="">Seleccione</option>
                       
                        <?php if( !empty( $areas ) ): foreach( $areas as $value ): ?>
                        	<option value="<?php echo $value['id_area']?>"><?php echo $value['nombre_area']?></option>
                        <?php endforeach; endif; ?>
                    	</select>
                    </div>
                    
                    
                    
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario3">
                    	<input type="file" name="imagen" style="display: none" id="imagen">
                        <!-- Fake field to fool the user -->
                        <input type="text"  name="valor" readonly id="valor">
                        <!-- Button to invoke the click of the File Input -->
                        <input type="button" id="boton-imagen" value="Subir Imagen" >
                    </div>
                    <div class="form-r formulario">
                    	<div class="label-n"><span class="etiqueta-n">Causa:</span></div>
                    	<select name="causa" id="causa" class="required">
                        	<option value="">Seleccione</option>
                       
							<?php if( !empty( $causas ) ): foreach( $causas as $value ): ?>
                                <option value="<?php echo $value['id_causa']?>"><?php echo $value['nombre_causa']?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    
                    
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario2">
                    	<div class="label-n"><span class="etiqueta-n">Asunto:</span></div>
                        <input type="text" name="asunto" id="asunto" class="required asunto" value="<?php echo set_value( 'asunto' )?>" />
                    </div>
                    
                    
                </div>
                <div class="fondo-form">
                	<div class="form-title"><span class="etiqueta-n">Insertar detalles del incidente:</span></div>
                </div>
                <div class="fondo-form">
                	
                    <textarea name="detalle" id="detalle" class="required ckeditor"><?php echo set_value('detalle');?></textarea>
                      
                </div>
                
                 <div class="fondo-form">
                	<div class="form-boton">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                         <input type="reset" class="form-insert" id="reset"  value="Limpiar"/>
                    </div>
                    
                </div>
            </form>
            <div class="clear"></div>
            <div class="top-form"></div>
         
        </div>    
      </div>
      <!--fin content-main-->