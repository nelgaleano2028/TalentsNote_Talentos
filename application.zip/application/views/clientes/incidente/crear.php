<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>
<!--content-main-->
<div id="content-main4"> 
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin">Ver Incidencia cliente:</span>
	
            </div>
         </div>
        <div class="content-on-blank">
        
          <div id="caja_dialogo" style="display: none;">
                <!-- aqui cargo la imagen del incidente  -->       
          </div>
        	<!--table-->
        	<div class="table_incidente">
            	 <div class="fondo-form">
                        <div class="form-l">
                            <div class="label-f"><span class="etiqueta-f">Codigo:</span> <span class="parf-f"><?php echo $incidencia[0]['id_incidencia'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Estado:</span> <?php echo $incidencia[0]['estado'];?></div>
                            <div class="label-f"><span class="etiqueta-f">Asunto:</span><span class="parf-f"> <?php echo $incidencia[0]['asunto'] ?> </span></div>
                           	 <?php
							$fecha=substr($incidencia[0]['fecha'], 0, -9);
                            $fecha = explode( '-', $fecha );
							$fecha = $fecha[2].'-'.$fecha[1].'-'.$fecha[0];
							?>
                            <div class="label-f"><span class="etiqueta-f">Fecha:</span> <span class="parf-f"><?php echo $fecha; ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Cliente:</span> <span class="parf-f"><?php echo $incidencia[0]['cliente'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Subcategoría:</span> <span class="parf-f"><?php echo $incidencia[0]['subcategoria'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Prioridad:</span> <?php echo $incidencia[0]['prioridad'] ?></div>
                           	<div class="label-f"><span class="etiqueta-f">Causa:</span> <span class="parf-f"><?php echo $incidencia[0]['causa'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Detalle:</span><?php echo $incidencia[0]['detalle']?>
                            <a href="javascript:void(0);" class="ver_imagen">Ver Imagen</a>
                             <div class="espacio"></div>
                            </div>
  
                        </div>
                       
                        
               		</div> 
                 <div class="separar"></div> 
                 <form action="<?php echo base_url() ?>clientes/incidente_crear/<?php echo $id_incidencia ?>" method="post" id="formincidente">
                 
                 	<div class="fondo-form">
                        <div class="form-l formulario">
                            <div class="label-c"><span class="etiqueta-f">Notas:</span></div>
                           
                        </div>
               		</div>
                    
                    <div class="fondo-form">
                           <textarea name="notas" id="notas" class="required ckeditor"></textarea>
               		</div>
                <div class="fondo-form">
                	
                    <div class="separar"></div>
                    <div class="form-boton2">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                        <input type="reset" id="reset" class="form-insert"  value="Limpiar"/>
                        <input type="button" class="form-insert ver_imagen"  value="Ver imagen"/>
                        <input type="hidden" name="id_imagen" id="id_imagen" value="<?php echo $incidencia[0]['id_incidencia'] ?>" />
                    </div>
                </div>
                 
                 </form>
                 <div class="clear"></div>
                 <div class="separar"></div> 
                <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                	<thead>
                        <tr>
                        	<th>Fecha</th>
                            <th ><center>Nota</center></th>
                            <th><center>Usuario</center></th>
                        </tr>
                    </thead>
                    <tfoot>
                    	<tr>
                        	
                        	<th>Fecha</th>
                            <th><center>Nota</center></th>
                            <th><center>Usuario</center></th>
                        </tr>
                   	<tfoot>
                    <tbody>
					   <?php  if( !empty( $notas ) ): foreach( $notas as $value ): ?>
                       
                       <?php $fecha = explode( ' ', $value['fecha'] ); ?>
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       <?php $fecha = explode( '-', $fecha[0] ); ?>
                       
                        <tr class="odd_gradeX">
                            <td width="100"><?php echo $fecha[2].'/'.$fecha[1].'/'.$fecha[0] ?></td>
                            <td><?php echo $value['notas'] ?></td>
                            <td><?php echo $value['usuario'] ?></td>
                            
                        </tr>
                   
                  		 <?php endforeach; endif; ?>
                   </tbody>
                   
                </table>

                
                <div class="top-form"></div>
    	
            </div>
            <!--table-->
            
          
          <!--fin cargar-->
        </div>    
</div>
<!--fin content-main-->