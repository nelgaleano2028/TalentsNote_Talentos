<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>

<!--content-main-->
<div id="content-main">  
		<div class="title-cliente">
        <div class="ingeniero">
            	 <span class="user-admin"><strong>Editar perfil: <?php echo $data[0]['nombre'] ?></strong></span>
                 
            	
            </div>
         </div>    
        
        <div class="content-on-blank">
        	 <?php $message = $this->session->flashdata( 'message' ); ?>
      
             <?php if( !empty( $message ) ): ?>
                   
              <!-- Notification messages -->
               <div class="nNote">
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="nFailure">
                       <p><strong>ERROR: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                   
                   <?php if( $message['type'] == 'img' ): ?>
                   <div class="nFailure">
                       <p><strong>ERROR: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                   
                   <?php if( $message['type'] == 'success' ): ?>
                   <div class="nSuccess">
                       <p><strong>CORRECTO: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                  
               </div>
              
              <?php endif; ?>
              
        	<form  action="<?php echo base_url() ?>clientes/perfil_cliente/<?php echo $data[0]['id_contacto'] ?>" method="post" id="formperfil" enctype="multipart/form-data">
            	
                
                 <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Celular o Fijo:</div>
                        <input type="text" name="telefono" id="telefono" class="required" value="<?php echo set_value('telefono',  $data[0]['telefono']) ?>"/>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Correo:</div>
                        <input type="text" name="correo" id="correo" class="required" value="<?php echo set_value('correo',  $data[0]['correo']) ?>"/>
                    </div>
                </div>
                
                 <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Contraseña:</div>
                        <input type="password" name="contrasena_original" id="contrasena_original"  />
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Nueva Contraseña:</div>
                        <input type="password" name="contrasena" id="contrasena"  />
                    </div>
                </div>
                
                 <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Repetir Contraseña:</div>
                        <input type="password" name="re_contrasena" id="re_contrasena"  />
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Avatar:</div>
                        <input type="file" name="foto" id="foto" />
                    </div>
                </div>
   				
                <div class="fondo-form">
                	
                    <div class="form-boton">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                        <input type="reset" id="reset" class="form-insert"  value="Limpiar"/>
                    </div>
                </div>
                <div class="clear"></div>
                <div class="top-form"></div>
                
            
            	
            </form>
         
        </div>    
</div>
<!--fin content-main-->