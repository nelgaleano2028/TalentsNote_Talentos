<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>

<!--content-main-->
<div id="content-main"> 
		<div class="title-cliente">
        <div class="ingeniero">
            	 <span class="user-admin">Editar : <?php echo $data[0]['nombre'] ?></span>
                 
            	
            </div>
         </div>     
       
        <div class="content-on-blank">
        <?php $message = $this->session->flashdata( 'message' ); ?>
      
             <?php if( !empty( $message ) ): ?>
                   
              <!-- Notification messages -->
               <div class="nNote">
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="nFailure">
                       <p><strong>ERROR: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                   
                   <?php if( $message['type'] == 'img' ): ?>
                   <div class="nFailure">
                       <p><strong>ERROR: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                   
                   <?php if( $message['type'] == 'success' ): ?>
                   <div class="nSuccess">
                       <p><strong>CORRECTO: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                  
               </div>
              
              <?php endif; ?>
              
              <?php $attributes=array('id'=>'formperfil');?> 
              <?php echo form_open_multipart('ingeniero/perfil_ingeniero/'.$data[0]['id_ingeniero'], $attributes);?>  
        	
            	
                
                 <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Celular o Fijo:</div>
                        <input type="text" name="celular" id="celular"  class="required" value="<?php echo set_value('celular', $data[0]['celular']) ?>"/>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Correo:</div>
                        <input type="text" name="correo" id="correo"  class="required" value="<?php echo set_value('correo', $data[0]['correo']) ?>"/>
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Contraseña:</div>
                        <input type="password" name="contrasena_original" id="contrasena_original"  />
                    </div>
                </div>
                
                 <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Nueva Contraseña:</div>
                        <input type="password" name="contrasena" id="contrasena"  />
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Repetir Contraseña:</div>
                        <input type="password" name="re_contrasena" id="re_contrasena"  />
                    </div>
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Avatar:</div>
                        <input type="file" name="foto" id="foto"/>
                    </div>
                </div>
   				
                <div class="fondo-form">
                	
                    <div class="form-boton">
                    	<input type="submit" class="form-insert"  value="Guardar"/>
                        <input type="reset" id="reset" class="form-insert"  value="Limpiar"/>
                    </div>
                </div>
                <div class="clear"></div>
                <div class="top-form"></div>
                
            
            	
            <?php echo form_close();?>
         
        </div>    
</div>
<!--fin content-main-->