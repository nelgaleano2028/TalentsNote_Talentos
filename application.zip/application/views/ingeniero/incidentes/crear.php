<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>

<!--content-main-->
<div id="content-main4"> 
        <div class="title-cliente">
        <div class="ingeniero">
            	 <span class="user-admin"><strong>Ver Incidencia Cliente:</strong></span>
            </div>
         </div>
        <div class="content-on-blank">
            <div id="caja_dialogo" style="display: none;">
                <!-- aqui cargo la imagen del incidente  -->
            </div>
             <?php $message = $this->session->flashdata( 'message' ); ?>
      
             <?php if( !empty( $message ) ): ?>
                   
              <!-- Notification messages -->
               <div class="nNote">
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="nFailure">
                       <p><strong>ERROR: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
               </div>
              
              <?php endif; ?>
            
        	<!--table-->
        	<div class="table_incidente">
            	
                    <div class="fondo-form">
                        <div class="form-l">
                         
                            <div class="label-f"><span class="etiqueta-f">Codigo:</span> <span class="parf-f"><?php echo $incidencia[0]['id_incidencia'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Estado:</span> <?php echo $incidencia[0]['estado']  ?>
						   </div>
                           <div class="label-f"><span class="etiqueta-f">Asunto:</span><span class="parf-f"> <?php echo $incidencia[0]['asunto'] ?> </span></div>
                           	 <?php
							$fecha=substr($incidencia[0]['fecha'], 0, -9);
                            $fecha = explode( '-', $fecha );
							$fecha = $fecha[2].'-'.$fecha[1].'-'.$fecha[0];
							?>
                            <div class="label-f"><span class="etiqueta-f">Fecha:</span> <span class="parf-f"><?php echo $fecha; ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Cliente:</span> <span class="parf-f"><?php echo $incidencia[0]['cliente'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Subcategoría:</span> <span class="parf-f"><?php echo $incidencia[0]['subcategoria'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Prioridad:</span>   <?php echo $incidencia[0]['prioridad'];?> </div>
                            <div class="label-f"><span class="etiqueta-f">Causa:</span> <span class="parf-f"><?php echo $incidencia[0]['causa'] ?></span></div>
                            <div class="label-f"><span class="etiqueta-f">Detalle:</span><?php echo $incidencia[0]['detalle'] ?>
                            <a href="javascript:void(0);" class="ver_imagen">Ver Imagen</a>
                             <div class="espacio"></div>
                            </div>
  
                        </div>
                       
                        
               		</div> 
                 <div class="separar"></div> 
                 <form action="<?php echo base_url() ?>ingeniero/incidente_crear/<?php echo $id_incidencia ?>" method="post" id="formincidente">
                 
                 	<div class="fondo-form">
                        <div class="form-l">
                            <div class="label-c"><span class="etiqueta-f">Notas:</span></div>
                           
                        </div>
               		</div>
                    
                    <div class="fondo-form">
                       <textarea name="notas" id="notas" class="required ckeditor"></textarea>
      
               		</div>   
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Actualizar Estado Incidencia:</div>
                        <select name="id_estado" id="id_estado" >
                        	<option value="<?php echo $incidencia[0]['id_estado'];?>" selected="selected"><?php echo $incidencia[0]['estado'];?></option>
                            <?php if( !empty( $estado ) ): foreach( $estado as $value ): ?>
                            	
                                	 <option value="<?php echo $value['id_estado'] ?>"><?php echo $value['nombre_estado'] ?></option>
                               	
							<?php endforeach; endif; ?>
                            
                        </select>
                    </div>
                    
                    <div class="form-l formulario">
                    	<div class="label">Actualizar Prioridad:</div>
                        <select name="id_condicion" id="id_condicion">
                        	<option value="<?php echo $incidencia[0]['id_prioridad'];?>" selected="selected"><?php echo $incidencia[0]['prioridad'];?></option>
                            <option value="1">Alta</option>
                            <option value="2">Media</option>
                            <option value="3">Baja</option>
                         </select>
                    </div>
                    
                    <div class="form-l formulario">
                    	<div class="label">Actualizar Area:</div>
                        <select name="id_area" id="id_area">
                            <option value=""> Seleccione</option>
                        	<?php if( !empty( $areas ) ): foreach( $areas as $value ): ?>
                            	
                                	 <option value="<?php echo $value['id_area'] ?>"><?php echo $value['nombre_area'] ?></option>
                               	
							<?php endforeach; endif; ?>
                        </select>
                    	</div> 
                </div>
                
                <div class="fondo-form">
                	<div class="form-l formulario">
                    	<div class="label">Causa:</div>
                        <select name="causa" id="causa"  >
                        <option value="<?php echo $incidencia[0]['id_causa'];?>" selected="selected"><?php echo $incidencia[0]['causa'];?></option>
                        <?php if( !empty( $causa ) ): foreach( $causa as $value ): ?>
                            	
                                	 <option value="<?php echo $value['id_causa'] ?>"><?php echo $value['nombre_causa'] ?></option>
                               	
						<?php endforeach; endif; ?>
                        	
                        </select>    
                    </div>
                    
                     <div class="form-l formulario">
                    	<div class="label">Ingeniero</div>
                        <select name="id_ingeniero" id="id_ingeniero">
                            
                        </select>
                           
                    </div>
                    <div class="clear"></div>
                    
                    <div class="form-boton2">
                    	<input type="submit" class="form-insert"  value="Guardar" id="click_seguro"/>
                        <input type="reset" id="reset" class="form-insert"  value="Limpiar"/>
                        <input type="button" class="form-insert ver_imagen"  value="Ver imagen"/>
                        <input type="hidden" name="id_imagen" id="id_imagen" value="<?php echo $incidencia[0]['id_incidencia'] ?>" />
                    </div>
                </div>
                 
                 </form>
                 
                 <div class="clear"></div>
                 <div class="separar"></div>
                 
                 
                 
                <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="tabla_ingeniero">
                	<thead>
                        <tr>
                        	<th>Fecha</th>
                            <th ><center>Nota</center></th>
                            <th><center>Usuario</center></th>
                        </tr>
                    </thead>
                    <tfoot>
                    	<tr>
                        	<th>Fecha</th>
                            <th><center>Nota</center></th>
                            <th><center>Usuario</center></th>
                        </tr>
                   	<tfoot>
                    <tbody>
					   <?php  if( !empty( $notas ) ): foreach( $notas as $value ): ?>
                       
                       <?php $fecha = explode( ' ', $value['fecha'] ); ?>
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       <?php $fecha = explode( '-', $fecha[0] ); ?>
                       
                        <tr class="odd_gradeX">
                            <td width="100"><?php echo $fecha[2].'/'.$fecha[1].'/'.$fecha[0] ?></td>
                            <td><?php echo $value['notas'] ?></td>
                            <td><?php echo $value['usuario']?></td>
                            
                        </tr>
                   
                  		 <?php endforeach; endif; ?>
                   </tbody>
                   
                </table>
                
                <div class="top-form"></div>
    	
            </div>
            <!--table-->
        </div>    
</div>
<!--fin content-main-->

