<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>

<!--content-main-->
<div id="content-main">      
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin"><strong>Libreta de direcciones:</strong></span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank-table">
        	
            <!--table-->
        	<div class="table_incidente">
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
                <thead>
                    <tr>
                        <th>Empresa</th>
                        <th>Contacto</th>
                        <th>Correo</th>
                        <th>Telefono</th>
                        <th>Usuario</th>
 
                    </tr>
                </thead>
                <tbody>
                    
                    <?php if( !empty( $data ) ): foreach( $data as $value ): ?>
                    
                    <tr >
                        <td><?php echo $value['empresa']?></td>
                        <td><?php echo $value['nombre'].'&nbsp;&nbsp;'. $value['apellido'] ?></td>
                        <td><?php echo $value['correo']?></td>
                        <td><?php echo $value['telefono'] ?></td>
                        <td><?php echo $value['usuario']?></td>
                        
                    </tr>
                   
                   <?php endforeach; endif; ?>
                    
                </tbody>
			</table>
            </div>
        	<!--Fin table-->
            
         
        </div>    
</div>
<!--fin content-main-->