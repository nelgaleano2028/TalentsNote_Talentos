<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>

<!--content-main-->
<div id="content-main">      
        <div class="title-cliente">
        <div class="ingeniero">
            	 <span class="user-admin"><strong>Incidentes por Clientes:</strong></span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank-table">
        	<!--table-->
        	<div class="table_incidente">
            
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
                <thead>
                    <tr>
                        <th>Codigo</th>
                        <th>Estado</th>
                        <th>Cliente</th> 
                        <th>Prioridad</th>
                        <th>Asunto</th>
                        <th>Contacto</th>
                        <th>Fecha</th>
                        <th>Fecha Final</th>
                        <th>Imprimir</th>
                        
                    </tr>
                </thead>
                <tbody>
                	 <?php if( !empty( $data ) ): foreach( $data as $value ): ?>
                    
                    <tr >
                        <td><?php echo $value['id_incidencia']?></td>
                        <td><?php 
								switch( $value['id_estado'] ):
									
									case 1:
										echo 'Abierto';
									break;
									
									case 2:
										echo 'Cerrado';
									break;
									
								endswitch;
								?></td>
                        <td><?php 
							
							 echo $value['cliente'] 
							
						
						?></td>
                        <td class="center"><?php
																								
								
								switch( $value['id_condicion'] ):
									
									case 1:
																															
										echo 'Alta';
											
									break;
									
									case 2:
																			
										echo 'Media';
											
									break;
									
									case 3:
										
										echo 'Baja';
											
									break;
									
								endswitch;
								
							 ?></td>
                        <td class="center"><?php echo $data[0]['asunto'] ?></td>
                        <td class="center"><?php echo $data[0]['contacto'] ?></td>
                        <td class="center"><?php echo $data[0]['fecha'] ?></td>
                        <td class="center"><?php echo $data[0]['fecha_final'] ?></td>
                        <td><a href="<?php echo base_url()?>ingeniero/reporte_print/<?php echo $value['id_incidencia'].'/pdf'?>" >
                        <img src="<?php echo base_url()?>images/pdf.png" width="20" height="20" alt="imprimir en pdf"  title="pdf"/>
                        
                        </a> || <a href="<?php echo base_url()?>ingeniero/reporte_print/<?php echo $value['id_incidencia'].'/xls'?>" >
                        <img src="<?php echo base_url()?>images/excel.png" width="20" height="20" alt="imprimir en pdf"  title="excel"/></a></td>
                             
                    </tr>
                   
                   <?php endforeach; endif; ?>
                    
                    
                              
                  
                   
                </tbody>
			</table>
            </div>
        	<!--Fin table-->
            
         
        </div>    
</div>
<!--fin content-main-->