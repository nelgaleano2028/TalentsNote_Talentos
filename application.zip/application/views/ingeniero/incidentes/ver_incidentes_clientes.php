<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
        $this->output->set_header( "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0" ); 
        $this->output->set_header( "Pragma: no-cache" ); 
?>

<!--content-main-->
<div id="content-main">      
        <div class="title-cliente">
        <div class="admin">
            	 <span class="user-admin"><strong>Incidentes por Clientes:</strong></span>
                 
            	
            </div>
         </div>
        <div class="content-on-blank-table">
        	
            <?php $message = $this->session->flashdata( 'message' ); ?>
      
             <?php if( !empty( $message ) ): ?>
                   
              <!-- Notification messages -->
               <div class="nNote">
                   <?php if( $message['type'] == 'failure' ): ?>
                   <div class="nFailure">
                       <p><strong>ERROR: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
               	  
                   <?php if( $message['type'] == 'success' ): ?>
                   <div class="nSuccess">
                       <p><strong>Correcto: </strong><?php echo $message['text'] ?></p>
                   </div>
                   <?php endif; ?>
                  
               </div>
              
              <?php endif; ?>
            
            <!--table-->
        	<div class="table_incidente">
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
                <thead>
                    <tr>
                        <th>Codigo</th>
                        <th>Estado</th>
                        <th>Asunto</th>
                        <th>Fecha</th>
                        <th>Prioridad</th>
                        <th>Empresa</th>
                        
                    </tr>
                </thead>
                <tbody>
                    
                    <?php if( !empty( $data ) ): foreach( $data as $value ): ?>
                    
                    <tr >
                        <td><?php echo $value['id_incidencia']?></td>
                        <td><?php echo $value['estado'] ?></td>
                        <td><?php echo anchor( '/ingeniero/incidente_crear/'.$value['id_incidencia'].'/'.$value['id_ingeniero'], $value['asunto'] )?></td>
                        <td class="center"><?php echo $value['fecha']?></td>
                        <td class="center"><?php
								
								if( !empty( $value['tiempo'][0]['horas'] ) ){
																	
									$datetime = explode( ' ', $value['fecha'] );
												
									$time = explode( ':', $datetime[1] );
								
								}
								
								
								switch( $value['id_condicion'] ):
									
									case 1:
										
										if( !empty( $value['tiempo'][0]['horas'] ) ){
										
											$hora1 = strtotime( "".$time[0].":".$time[1]."" );
												
											if( $time[0] == 24 ){
													$hora2 = 1;
											}else{
												$hora2 = $time[0] + $value['tiempo'][0]['horas'];
											}
												
											$hora2 = strtotime( "".$hora2.":".$time[1]."" );
											
											if( $hora1 < $hora2 ) {
												
												echo '<div style="background-color:#A80004; width:20px; height:10px;" title=" Prioridad Mayor"></div>';
											
											} else {
												echo '<div style="background-color:#421A86; width:20px; height:10px;" title=" Prioridad Alta"></div>';
											}
										
										}else
										
																															
										echo '<div style="background-color:#A80004; width:20px; height:10px;" title=" Prioridad Alta"></div>';
											
									break;
									
									case 2:
										
										if( !empty( $value['tiempo'][0]['horas'] ) ){
										
											$hora1 = strtotime( "".$time[0].":".$time[1]."" );
												
											if( $time[0] == 24 ){
													$hora2 = 1;
											}else{
												$hora2 = $time[0] + $value['tiempo'][0]['horas'];
											}
												
											$hora2 = strtotime( "".$hora2.":".$time[1]."" );
											
											if( $hora1 < $hora2 ) {
												echo '<div style="background-color:#F77A1E; width:20px; height:10px;" title=" Prioridad Alta"></div>';
											} else {
												echo '<div style="background-color:#A80004; width:20px; height:10px;" title=" Prioridad Media"></div>';
											}
										
										}else
										
											echo '<div style="background-color:#F77A1E; width:20px; height:10px;" title=" Prioridad Media"></div>';
											
									break;
									
									case 3:
										
										if( !empty( $value['tiempo'][0]['horas'] ) ){
											
											$hora1 = strtotime( "".$time[0].":".$time[1]."" );
												
											if( $time[0] == 24 ){
													$hora2 = 1;
											}else{
												$hora2 = $time[0] + $value['tiempo'][0]['horas'];
											}
												
												
											$hora2 = strtotime( "".$hora2.":".$time[1]."" );
												
											if( $hora1 < $hora2 ) {
											
												$hora2 = $time[0] + $value['tiempo'][0]['horas'] + $value['tiempo'][0]['horas'];
												
												$hora2 = strtotime( "".$hora2.":".$time[1]."" );
												
												
												if( $hora1 < $hora2 ) 
													
													echo '<div style="background-color:#A80004; width:20px; height:10px;" title=" Prioridad Alta"></div>';
													
												else												
												
													echo '<div style="background-color:#F2E435; width:20px; height:10px;" title=" Prioridad Media"></div>';
											
											} else {
												echo '<div style="background-color:#F77A1E; width:20px; height:10px;" title=" Prioridad Media"></div>';
											}
										
										}else
										
											echo '<div style="background-color:#F2E435; width:20px; height:10px;" title=" Prioridad Baja"></div>';
											
									break;
									
								endswitch;
								
							 ?></td>
                        <td class="center"><?php echo $value['cliente'] ?></td>
                        
                    </tr>
                   
                   <?php endforeach; endif; ?>
                    
                </tbody>
			</table>
            </div>
        	<!--Fin table-->
            
         
        </div>    
</div>
<!--fin content-main-->