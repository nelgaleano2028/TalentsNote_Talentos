<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Estadistica extends CI_Controller{	
	
	public $view = array();

	public $login = array();
	
	public $data = array();
	
	public $nombre= array();
	
	public $realizados= array();

	public function __construct(){ 
		
		parent::__construct(); 
						
		// Permisos
		$this->login = $this->session->userdata( 'login' );
		
		if( empty( $this->login ) ) redirect( '/usuario/login', 'refresh' );
				
		if( $this->login[0]['id_perfil'] != 1 ){
						
			$message = array(
			
				'type' => 'warning',
				'text' => 'No tiene permisos para accesar a esta área..' 
			
			);
			
			
			redirect( '/admin/', 'refresh' );
		
		}
						
	}	
	
	public function cliente(){
		
		// Load Model
		$this->load->model( array( 'cliente', 'ingenieros' ) );
		
		$this->view=array(
			'title'=>'Talents Notes',
			'css'=>array(
				
				'<link rel="stylesheet" href="'.base_url().'style/smoothness/jquery-ui-1.8.4.custom.css" type="text/css" />'
				
			),
			'scripts'=>array(
				'<script type="text/javascript" src="'.base_url().'scripts/general.js"></script>',
				'<script  type="text/javascript" src="'.base_url().'scripts/jquery-ui.min.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/jquery.ui.datepicker-es.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/date.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/jsapi.js"></script>',
				/*'<script type="text/javascript" src="http://www.google.com/jsapi"></script>',*/
				'<script type="text/javascript" src="'.base_url().'scripts/jquery.gvChart-1.0.min.js"></script>',
				'<script type="text/javascript">
					gvChartInit();
				</script>',
				'<script type="text/javascript" src="'.base_url().'scripts/estadisticas/file.js"></script>',
				'<script type="text/javascript" language="javascript">
					$(function() {
						$("#tool-tip").hide();
						$(".btmiddle").click(function() {
							if ($(".btmiddle").hasClass("bt")) {
								$(".btmiddle").removeClass("bt");
								$(".btmiddle").addClass("clicked");
								$("#tool-tip").show();
							} else {
								$(".btmiddle").removeClass("clicked");
								$(".btmiddle").addClass("bt");
								$("#tool-tip").hide();
							}
						});
					});
				</script>'
				
				
			),
			'login' => $this->login,
			'section' => 'inicio',
			'content' => 'admin/estadisticas/ver2',
			'clientes' => $this->cliente->all(),
			'ingenieros' => $this->ingenieros->all()
			
	    );
		
		$this->load->view( 'includes/include', $this->view );
		
	}
	
	
	public function ingeniero(){
		
		// Load Model
		$this->load->model( array( 'cliente', 'ingenieros' ) );
		
		$this->view=array(
			'title'=>'Talents Notes',
			'css'=>array(
				
				'<link rel="stylesheet" href="'.base_url().'style/smoothness/jquery-ui-1.8.4.custom.css" type="text/css" />'
				
			),
			'scripts'=>array(
				'<script type="text/javascript" src="'.base_url().'scripts/general.js"></script>',
				'<script  type="text/javascript" src="'.base_url().'scripts/jquery-ui.min.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/jquery.ui.datepicker-es.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/date.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/jsapi.js"></script>',
				/*'<script type="text/javascript" src="http://www.google.com/jsapi"></script>',*/
				'<script type="text/javascript" src="'.base_url().'scripts/jquery.gvChart-1.0.min.js"></script>',
				'<script type="text/javascript">
					gvChartInit();
				</script>',
				'<script type="text/javascript" src="'.base_url().'scripts/estadisticas/file.js"></script>',
				'<script type="text/javascript" language="javascript">
					$(function() {
						$("#tool-tip").hide();
						$(".btmiddle").click(function() {
							if ($(".btmiddle").hasClass("bt")) {
								$(".btmiddle").removeClass("bt");
								$(".btmiddle").addClass("clicked");
								$("#tool-tip").show();
							} else {
								$(".btmiddle").removeClass("clicked");
								$(".btmiddle").addClass("bt");
								$("#tool-tip").hide();
							}
						});
					});
				</script>'
				
				
			),
			'login' => $this->login,
			'section' => 'lista',
			'content' => 'admin/estadisticas/ver',
			'clientes' => $this->cliente->all(),
			'ingenieros' => $this->ingenieros->all()
			
	    );
		
		$this->load->view( 'includes/include', $this->view );
		
	}
	
	public function ingenieros(){
		
		if( $this->login[0]['id_perfil'] != 1 ){
						
			$message = array(
			
				'type' => 'warning',
				'text' => 'No tiene permisos para accesar a esta área..' 
			
			);
		}
		
		

		$this->load->model('ingenieros');
		$ingeniero=$this->ingenieros->all2();

		
		$this->view=array(
			'title'=>'Talents Notes',
			'css'=>array(
				
				'<link rel="stylesheet" href="'.base_url().'style/demo_page.css" type="text/css" />',
                '<link rel="stylesheet" href="'.base_url().'style/demo_table_jui.css" type="text/css" />',
                '<link rel="stylesheet" href="'.base_url().'style/smoothness/jquery-ui-1.8.4.custom.css" type="text/css"/>',
				
				
			),
			'scripts'=>array(
				
				'<script type="text/javascript" src="'.base_url().'scripts/datatable.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/jquery.dataTables.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/general.js"></script>',
				'<script  type="text/javascript" src="'.base_url().'scripts/jquery-ui.min.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/jquery.ui.datepicker-es.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/date.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/highcharts/highcharts.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/highcharts/modules/exporting.js"></script>',

				'<script type="text/javascript" src="'.base_url().'scripts/estadisticas/file.js"></script>',
				'<script type="text/javascript" language="javascript">
					$(function() {
						$("#tool-tip").hide();
						$(".btmiddle").click(function() {
							if ($(".btmiddle").hasClass("bt")) {
								$(".btmiddle").removeClass("bt");
								$(".btmiddle").addClass("clicked");
								$("#tool-tip").show();
							} else {
								$(".btmiddle").removeClass("clicked");
								$(".btmiddle").addClass("bt");
								$("#tool-tip").hide();
							}
						});
					});
				</script>'
	
			),
			'login' => $this->login,
			'ingeniero'=>$ingeniero,
			'section' => 'estadistica',
			'content' => 'admin/estadisticas/ver3',
			
			
	    );
		
		$this->load->view( 'includes/include', $this->view );
	}
	
	public function ingenieros2(){
		
		if( $this->login[0]['id_perfil'] != 1 ){
						
			$message = array(
			
				'type' => 'warning',
				'text' => 'No tiene permisos para accesar a esta área..' 
			
			);
		}
		
		$this->load->model('ingenieros');
		$ingeniero=$this->ingenieros->all2();

		
		$this->view=array(
			'title'=>'Talents Notes',
			'css'=>array(
				
				'<link rel="stylesheet" href="'.base_url().'style/demo_page.css" type="text/css" />',
                '<link rel="stylesheet" href="'.base_url().'style/demo_table_jui.css" type="text/css" />',
                '<link rel="stylesheet" href="'.base_url().'style/smoothness/jquery-ui-1.8.4.custom.css" type="text/css"/>',
				
				
			),
			'scripts'=>array(
				
				'<script type="text/javascript" src="'.base_url().'scripts/datatable.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/jquery.dataTables.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/general.js"></script>',
				'<script  type="text/javascript" src="'.base_url().'scripts/jquery-ui.min.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/jquery.ui.datepicker-es.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/date.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/highcharts/highcharts.js"></script>',
				'<script type="text/javascript" src="'.base_url().'scripts/highcharts/modules/exporting.js"></script>',

				'<script type="text/javascript" src="'.base_url().'scripts/estadisticas/file.js"></script>',
				'<script type="text/javascript" language="javascript">
					$(function() {
						$("#tool-tip").hide();
						$(".btmiddle").click(function() {
							if ($(".btmiddle").hasClass("bt")) {
								$(".btmiddle").removeClass("bt");
								$(".btmiddle").addClass("clicked");
								$("#tool-tip").show();
							} else {
								$(".btmiddle").removeClass("clicked");
								$(".btmiddle").addClass("bt");
								$("#tool-tip").hide();
							}
						});
					});
				</script>'
	
			),
			'login' => $this->login,
			'ingeniero'=>$ingeniero,
			'section' => 'estadistica',
			'content' => 'admin/estadisticas/ver4',
			
			
	    );
		
		$this->load->view( 'includes/include', $this->view );
	}
	
	
	
	
/*
=====================================
	AJAX REQUEST
===================================== */		
	public function contactos(){
		
		if( $this->input->is_ajax_request() == false ) return false;
		
		if( empty( $_POST['cliente'] ) or !is_numeric( $_POST['cliente'] ) ) return false;
		
		// Load Model
		$this->load->model( 'contactos' );
		
		$this->data = $this->contactos->cliente( $_POST['cliente'] );
		
		$data = '<option value="">Seleccione...</option>';
		
		if( empty( $this->data  ) ){ echo $data; return false; }
		
		foreach( $this->data as $value ){
			
			$data .= '<option value="'.$value['id_contacto'].'">'.$value['nombre'].'</option>';
			
		}	
		
		echo $data;
		
		return false;
				
	}
	
	public function resultados(){
		
		if( $this->input->is_ajax_request() == false ) return false;
		
		if( empty( $_POST['cliente'] ) or !is_numeric( $_POST['cliente'] ) or  empty( $_POST['ingeniero'] ) or !is_numeric( $_POST['ingeniero'] ) or  empty( $_POST['fecha'] ) ) return false;
		
		// Load Model
		$this->load->model( 'incidencia' );
		
		$realizadas = $this->incidencia->realizadas( $_POST['cliente'], $_POST['ingeniero'], $_POST['fecha']);
		
		$no_realizadas = $this->incidencia->no_realizadas( $_POST['cliente'], $_POST['ingeniero'], $_POST['fecha']);
		
		unset( $this->data ); 
		
			$this->data = array(
				
				'realizadas' => $realizadas[0]['numero'],
				'no_realizadas' => $no_realizadas[0]['numero']
				
			);
		
		echo  json_encode( $this->data ) ;
						
	}
	
	
	public function resultados2(){
		
		if( $this->input->is_ajax_request() == false ) return false;
		
		if( empty( $_POST['ingeniero1'] ) or !is_numeric( $_POST['ingeniero1'] ) or  empty( $_POST['ingeniero2'] ) or !is_numeric( $_POST['ingeniero2'] ) or  empty( $_POST['fecha'] ) ) return false;
		
		// Load Model
		$this->load->model( array( 'incidencia', 'ingenieros' ) );
		
		$ingeniero1 = $this->ingenieros->id( $_POST['ingeniero1'] );
		
		$realizadas1 = $this->incidencia->realizadas_ingeniero_fecha( $_POST['ingeniero1'], $_POST['fecha'] );
		
		$no_realizadas1 = $this->incidencia->no_realizadas_ingeniero_fecha( $_POST['ingeniero1'], $_POST['fecha'] );
		
		$ingeniero2 = $this->ingenieros->id( $_POST['ingeniero2'] );
		
		$realizadas2 = $this->incidencia->realizadas_ingeniero_fecha( $_POST['ingeniero2'], $_POST['fecha'] );
		
		$no_realizadas2 = $this->incidencia->no_realizadas_ingeniero_fecha( $_POST['ingeniero2'], $_POST['fecha'] );
		
		
		unset( $this->data ); 
		
			$this->data = array(
				
				'ingeniero1' => $ingeniero1[0]['nombre'],
				'realizadas_1' => $realizadas1[0]['numero'],
				'no_realizadas_1' => $no_realizadas1[0]['numero'],
				'ingeniero2' => $ingeniero2[0]['nombre'],
				'realizadas_2' => $realizadas2[0]['numero'],
				'no_realizadas_2' => $no_realizadas2[0]['numero']
				
				
			);
		
		
		echo  json_encode( $this->data ) ;
						
	}
	
	public function resultados3(){
		
		if( $this->input->is_ajax_request() == false ) return false;

		 //Load Model
		$this->load->model( array( 'incidencia', 'ingenieros' ) );
		
		if($_POST['id_ingeniero'][0]== 'on')
		{
			
			unset($_POST['id_ingeniero'][0]); // borrar la casilla que elige a todos los ingenieros
		}
		
		$ingeniero=$this->input->post('id_ingeniero');
		
		unset( $this->data);
		
		$total=0;
		
		foreach($ingeniero as $check){
			
			$realizadas = $this->incidencia->realizadas_ingeniero_fecha( $check, $_POST['fecha1'], $_POST['fecha2'] );
			
		
				$total=$total + $realizadas[0]['numero'];
						
		}
		
		
		foreach($ingeniero as $check){
			
			$realizadas= $this->incidencia->realizadas_ingeniero_fecha( $check, $_POST['fecha1'], $_POST['fecha2'] );
			$ingenieros= $this->ingenieros->id( $check );
			
				//si el total es cero mensaje

				  $estadistica= (100 * $realizadas[0]['numero']) / $total;
				  
				  $y=round($estadistica);
				  
		  
				  $this->data[]=array(
					  'name'=>$ingenieros[0]['nombre'],
					  'y' => $y,
				  
				  );

		}
		
		echo  json_encode(array( 'datos'=>$this->data, 'peticion'=>'ok')) ;
		
		
    }
	
	public function resultados4(){
		
		if( $this->input->is_ajax_request() == false ) return false;

		 //Load Model
		$this->load->model( array( 'incidencia', 'ingenieros' ) );
		
		if($_POST['id_ingeniero'][0]== 'on')
		{
			
			unset($_POST['id_ingeniero'][0]); // borrar la casilla que elige a todos los ingenieros
		}
		
		$ingeniero=$this->input->post('id_ingeniero');
		
		unset( $this->data);
		
		$total=0;
		
		foreach($ingeniero as $check){
			
			$realizadas = $this->incidencia->no_realizadas_ingeniero_fecha( $check, $_POST['fecha1'], $_POST['fecha2'] );
			
		
				$total=$total + $realizadas[0]['numero'];
						
		}
		
		
		foreach($ingeniero as $check){
			
			$realizadas= $this->incidencia->no_realizadas_ingeniero_fecha( $check, $_POST['fecha1'], $_POST['fecha2'] );
			$ingenieros= $this->ingenieros->id( $check );
			
				//si el total es cero mensaje

				  $estadistica= (100 * $realizadas[0]['numero']) / $total;
				  
				  $y=round($estadistica);
				  
		  
				  $this->data[]=array(
					  'name'=>$ingenieros[0]['nombre'],
					  'y' => $y,
				  
				  );

		}
		
		echo  json_encode(array( 'datos'=>$this->data, 'peticion'=>'ok')) ;
		
		
    }
		
}
?>